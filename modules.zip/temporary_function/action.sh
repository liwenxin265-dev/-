#!/system/bin/sh
MODDIR=${0%/*}
CONFIG=$MODDIR/config.ini
LOCK=$MODDIR/.config.lock
setval(){
 while ! mkdir "$LOCK" 2>/dev/null; do sleep 0.05; done
 sed -i "/^\[$1\]/,/^\[/ s/^enable=.*/enable=$2/" "$CONFIG"
 rmdir "$LOCK"
}
case "$1" in
get) cat "$CONFIG";;
mt) setval MT "$2";;
tmp) setval TMP "$2";;
logs) cat "$MODDIR/status.log" 2>/dev/null;;
esac
