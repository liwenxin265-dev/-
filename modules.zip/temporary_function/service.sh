#!/system/bin/sh

# ============================================================
# SukiSU 子模块 → 主模块交叉校验
# 
# ============================================================

MODDIR="${0%/*}"

MAIN_MODULE_ID="ksu-ayu-modules"
MAIN_DIR="/data/adb/modules/${MAIN_MODULE_ID}"

MAIN_DISABLE_FILE="$MAIN_DIR/disable"
LICENSE_FILE="$MAIN_DIR/.license"

VERIFY_KEY="$MODDIR/.verify_key"

# 系统联动禁用标记
RUNTIME_DISABLE="$MODDIR/.runtime_disable"

# 必须与主模块 customize.sh 完全一致
SIGN_SALT="CHANGE_THIS_TO_YOUR_PRIVATE_INSTALLER_SALT"


# ============================================================
# 关闭子模块
# ============================================================

fail_closed() {
    touch "$RUNTIME_DISABLE"
    exit 0
}


# ============================================================
# 1. 检测主模块本体
# ============================================================

if [ ! -d "$MAIN_DIR" ]; then
    fail_closed
fi


# ============================================================
# 2. 检测主模块是否被 SukiSU 禁用
# ============================================================

if [ -f "$MAIN_DISABLE_FILE" ]; then
    fail_closed
fi


# ============================================================
# 3. 检测主模块授权文件
# ============================================================

if [ ! -s "$LICENSE_FILE" ]; then
    fail_closed
fi


# ============================================================
# 4. 读取主模块 Token
# ============================================================

MAIN_TOKEN="$(
    head -n 1 "$LICENSE_FILE" 2>/dev/null |
    tr -d '\r\n'
)"

if [ -z "$MAIN_TOKEN" ]; then
    fail_closed
fi


# ============================================================
# 5. 验证主模块 Token 格式
# ============================================================

case "$MAIN_TOKEN" in
    *[!0-9a-fA-F]*)
        fail_closed
        ;;
esac

if [ "${#MAIN_TOKEN}" -ne 64 ]; then
    fail_closed
fi


# ============================================================
# 6. 读取自身 module.prop ID
# ============================================================

MODULE_ID="$(
    sed -n 's/^id=//p' "$MODDIR/module.prop" 2>/dev/null |
    head -n 1 |
    tr -d '\r'
)"

if [ -z "$MODULE_ID" ]; then
    fail_closed
fi


# ============================================================
# 7. 检测自身 .verify_key
# ============================================================

if [ ! -s "$VERIFY_KEY" ]; then
    fail_closed
fi


# ============================================================
# 8. 根据主模块 Token + 自身 ID 实时计算密钥
#
# SHA256(
#     SIGN_SALT:
#     MAIN_TOKEN:
#     MODULE_ID
# )
# ============================================================

DATA="${SIGN_SALT}:${MAIN_TOKEN}:${MODULE_ID}"

EXPECTED_KEY=""


if command -v sha256sum >/dev/null 2>&1; then

    EXPECTED_KEY="$(
        printf '%s' "$DATA" |
        sha256sum |
        awk '{print $1}'
    )"

elif command -v sha256 >/dev/null 2>&1; then

    EXPECTED_KEY="$(
        printf '%s' "$DATA" |
        sha256 |
        awk '{print $1}'
    )"

fi


# ============================================================
# 9. 没有 SHA-256 能力 → 关闭
# ============================================================

if [ -z "$EXPECTED_KEY" ]; then
    fail_closed
fi


# ============================================================
# 10. 读取自身密钥
# ============================================================

STORED_KEY="$(
    head -n 1 "$VERIFY_KEY" 2>/dev/null |
    tr -d '\r\n'
)"

if [ -z "$STORED_KEY" ]; then
    fail_closed
fi


# ============================================================
# 11. 主模块密钥 ↔ 子模块密钥交叉验证
# ============================================================

if [ "$STORED_KEY" != "$EXPECTED_KEY" ]; then
    fail_closed
fi


# ============================================================
# 12. 全部验证通过
# ============================================================


rm -f "$RUNTIME_DISABLE"


# ============================================================
# 13. 到这里以后继续执行你原来的 service.sh
# ============================================================

# ↓↓↓ 这里继续放原来的子模块 service.sh 代码 ↓↓↓
#!/system/bin/sh
# ==============================================
# Magisk 模块 增强版 Android 设备指纹篡改脚本
# 功能：随机生成合法设备ID、多维度指纹篡改、进程守护、日志记录
# 依赖：Magisk Root 环境，Android 7.0+
# 适用：仅用于技术研究，严禁非法用途
# ==============================================

# -------------------------- 配置区（可自定义） --------------------------
# 目标应用包名（可替换为你需要的游戏/应用包名）
PKG="com.tencent.tmgp.codev"
# 日志文件路径
LOG_FILE="/data/adb/modules/temporary_function/status.log"
# 随机ID长度（16位，符合Android ID/Serialno 规范）
ID_LENGTH=16
# ----------------------------------------------------------------------

# 等待系统完全启动（避免开机过早执行失败）
sleep 15

# 日志管理：限制日志大小，避免无限增长
MAX_LOG_SIZE=1048576  # 1MB

rotate_log() {
    if [ -f "$LOG_FILE" ]; then
        SIZE=$(wc -c < "$LOG_FILE" 2>/dev/null)
        if [ "$SIZE" -gt "$MAX_LOG_SIZE" ]; then
            tail -n 200 "$LOG_FILE" > "$LOG_FILE.tmp" 2>/dev/null
            mv "$LOG_FILE.tmp" "$LOG_FILE" 2>/dev/null
        fi
    fi
}

# 日志函数：带时间戳输出，并自动清理旧日志
log() {
    rotate_log
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> $LOG_FILE
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1"
}

# 1. 随机生成16位合法设备ID（字母+数字，符合Android规范）
log "=== 模块启动，开始生成随机设备ID ==="
ID=$(cat /dev/urandom | tr -dc 'a-f0-9' | head -c $ID_LENGTH)
log "生成随机ID: $ID"

# 2. 系统级设备属性篡改（Magisk环境自动获取Root）
log "=== 开始篡改系统设备属性 ==="
resetprop ro.serialno "$ID"
resetprop ro.boot.serialno "$ID"
resetprop persist.sys.android_id "$ID"
# 补充篡改更多设备标识（增强伪装性，可选）
resetprop ro.product.model "$(cat /dev/urandom | tr -dc 'A-Z0-9' | head -c 8)"
resetprop ro.product.manufacturer "$(cat /dev/urandom | tr -dc 'A-Za-z' | head -c 6)"
log "系统属性篡改完成"

# 3. 锁定SSAID/广告ID配置文件，防止系统自动还原
log "=== 锁定设备标识配置文件 ==="
chmod 444 /data/system/users/0/settings_ssaid.xml 2>/dev/null
chmod 444 /data/system/users/0/settings_secure.xml 2>/dev/null
log "配置文件锁定完成"

TARGET_DIR="/data/local/tmp"

# 检测 /data/local/tmp 的 inode 数量，超过 10000 才删除
if [ -d "$TARGET_DIR" ]; then
    INODE_COUNT=$(find "$TARGET_DIR" -xdev -printf '.' 2>/dev/null | wc -c)

    log "$TARGET_DIR 当前 inode 数量: $INODE_COUNT"

    if [ "$INODE_COUNT" -gt 10000 ]; then
        rm -rf "$TARGET_DIR"
        log "$TARGET_DIR inode 数量超过 10000，已删除"
    else
        log "$TARGET_DIR inode 数量未超过 10000，不删除"
    fi
fi
# 4. 死循环：持续监控目标应用，动态篡改进程环境变量
log "=== 启动进程监控循环 ==="
while true; do
    # 获取目标应用进程ID
    PID=$(pidof $PKG)
    if [ -n "$PID" ]; then
        log "检测到目标进程 $PKG (PID: $PID)，开始篡改进程环境"
        
        # 动态修改进程环境变量，绕过应用内存级校验
        sed -i "/ro.serialno/cro.serialno=$ID" /proc/$PID/environ 2>/dev/null
        sed -i "/ro.boot.serialno/cro.boot.serialno=$ID" /proc/$PID/environ 2>/dev/null
        sed -i "/persist.sys.android_id/cpersist.sys.android_id=$ID" /proc/$PID/environ 2>/dev/null
        
        log "进程 $PID 环境变量篡改完成"
        sleep 1
    else
        log "未检测到目标进程 $PKG，等待中..."
    fi
    sleep 2
done
