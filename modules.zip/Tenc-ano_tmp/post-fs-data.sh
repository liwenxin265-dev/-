#阿灵是人间理想
chmod 700 /mnt/vendor/persist/data 2>/dev/null