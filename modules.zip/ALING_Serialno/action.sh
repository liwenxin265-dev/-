#!/bin/sh

echo ""
echo -e "                  清者自清，没开就是没开"
sleep 1s
echo -ne '                     □□□□□□□□□□0% '
sleep 0.1
echo -ne '                     ■■■■■■■■■■100% '
sleep 0.1

    echo ""
    echo "😔红线划过深藏轮回的秘密"
    echo "😭我挥霍运气"
    echo "💔因为你才让我背对命运不害怕"
    
    sleep 1

    
    
Serialno=$(tr -dc 'A-Za-z0-9' < /dev/urandom | head -c 15)

echo ""
echo "- - - - - - - - - -"
echo "清者自清，没开就是没开"
echo "- - - - - - - - - -"
echo ""

echo "$Serialno
" >/data/adb/modules/ALING_Serialno/Serialno/
chmod 777 /data/adb/modules/ALING_Serialno/Serialno/Serialno.sh
sleep 1
/data/adb/modules/ALING_Serialno/Serialno/Serialno.sh


