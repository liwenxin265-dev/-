MODDIR=${0%/*}

$MODDIR/bin/zygiskd exit
