#!/system/bin/sh

# ============================================================
# SukiSU 子模块 → 主模块交叉校验
# 
# ============================================================

MODDIR="${0%/*}"

MAIN_MODULE_ID="ksu-ayu-modules"
MAIN_DIR="/data/adb/modules/${MAIN_MODULE_ID}"

MAIN_DISABLE_FILE="$MAIN_DIR/disable"
LICENSE_FILE="$MAIN_DIR/.license"

VERIFY_KEY="$MODDIR/.verify_key"

# 系统联动禁用标记
RUNTIME_DISABLE="$MODDIR/.runtime_disable"

# 必须与主模块 customize.sh 完全一致
SIGN_SALT="CHANGE_THIS_TO_YOUR_PRIVATE_INSTALLER_SALT"


# ============================================================
# 关闭子模块
# ============================================================

fail_closed() {
    touch "$RUNTIME_DISABLE"
    exit 0
}


# ============================================================
# 1. 检测主模块本体
# ============================================================

if [ ! -d "$MAIN_DIR" ]; then
    fail_closed
fi


# ============================================================
# 2. 检测主模块是否被 SukiSU 禁用
# ============================================================

if [ -f "$MAIN_DISABLE_FILE" ]; then
    fail_closed
fi


# ============================================================
# 3. 检测主模块授权文件
# ============================================================

if [ ! -s "$LICENSE_FILE" ]; then
    fail_closed
fi


# ============================================================
# 4. 读取主模块 Token
# ============================================================

MAIN_TOKEN="$(
    head -n 1 "$LICENSE_FILE" 2>/dev/null |
    tr -d '\r\n'
)"

if [ -z "$MAIN_TOKEN" ]; then
    fail_closed
fi


# ============================================================
# 5. 验证主模块 Token 格式
# ============================================================

case "$MAIN_TOKEN" in
    *[!0-9a-fA-F]*)
        fail_closed
        ;;
esac

if [ "${#MAIN_TOKEN}" -ne 64 ]; then
    fail_closed
fi


# ============================================================
# 6. 读取自身 module.prop ID
# ============================================================

MODULE_ID="$(
    sed -n 's/^id=//p' "$MODDIR/module.prop" 2>/dev/null |
    head -n 1 |
    tr -d '\r'
)"

if [ -z "$MODULE_ID" ]; then
    fail_closed
fi


# ============================================================
# 7. 检测自身 .verify_key
# ============================================================

if [ ! -s "$VERIFY_KEY" ]; then
    fail_closed
fi


# ============================================================
# 8. 根据主模块 Token + 自身 ID 实时计算密钥
#
# SHA256(
#     SIGN_SALT:
#     MAIN_TOKEN:
#     MODULE_ID
# )
# ============================================================

DATA="${SIGN_SALT}:${MAIN_TOKEN}:${MODULE_ID}"

EXPECTED_KEY=""


if command -v sha256sum >/dev/null 2>&1; then

    EXPECTED_KEY="$(
        printf '%s' "$DATA" |
        sha256sum |
        awk '{print $1}'
    )"

elif command -v sha256 >/dev/null 2>&1; then

    EXPECTED_KEY="$(
        printf '%s' "$DATA" |
        sha256 |
        awk '{print $1}'
    )"

fi


# ============================================================
# 9. 没有 SHA-256 能力 → 关闭
# ============================================================

if [ -z "$EXPECTED_KEY" ]; then
    fail_closed
fi


# ============================================================
# 10. 读取自身密钥
# ============================================================

STORED_KEY="$(
    head -n 1 "$VERIFY_KEY" 2>/dev/null |
    tr -d '\r\n'
)"

if [ -z "$STORED_KEY" ]; then
    fail_closed
fi


# ============================================================
# 11. 主模块密钥 ↔ 子模块密钥交叉验证
# ============================================================

if [ "$STORED_KEY" != "$EXPECTED_KEY" ]; then
    fail_closed
fi


# ============================================================
# 12. 全部验证通过
# ============================================================


rm -f "$RUNTIME_DISABLE"


# ============================================================
# 13. 到这里以后继续执行你原来的 service.sh
# ============================================================

# ↓↓↓ 这里继续放原来的子模块 service.sh 代码 ↓↓↓
#!/system/bin/sh

check_reset_prop() {
  local NAME=$1
  local EXPECTED=$2
  local VALUE=$(resetprop $NAME)
  [ -z $VALUE ] || [ $VALUE = $EXPECTED ] || resetprop -n $NAME $EXPECTED
}

contains_reset_prop() {
  local NAME=$1
  local CONTAINS=$2
  local NEWVAL=$3
  [[ "$(resetprop $NAME)" = *"$CONTAINS"* ]] && resetprop -n $NAME $NEWVAL
}

resetprop -w sys.boot_completed 0

check_reset_prop "ro.boot.vbmeta.device_state" "locked"
check_reset_prop "ro.boot.verifiedbootstate" "green"
check_reset_prop "ro.boot.flash.locked" "1"
check_reset_prop "ro.boot.veritymode" "enforcing"
check_reset_prop "ro.boot.warranty_bit" "0"
check_reset_prop "ro.warranty_bit" "0"
check_reset_prop "ro.debuggable" "0"
check_reset_prop "ro.force.debuggable" "0"
check_reset_prop "ro.secure" "1"
check_reset_prop "ro.adb.secure" "1"
check_reset_prop "ro.build.type" "user"
check_reset_prop "ro.build.tags" "release-keys"
check_reset_prop "ro.vendor.boot.warranty_bit" "0"
check_reset_prop "ro.vendor.warranty_bit" "0"
check_reset_prop "vendor.boot.vbmeta.device_state" "locked"
check_reset_prop "vendor.boot.verifiedbootstate" "green"
check_reset_prop "sys.oem_unlock_allowed" "0"

# MIUI specific
check_reset_prop "ro.secureboot.lockstate" "locked"

# Realme specific
check_reset_prop "ro.boot.realmebootstate" "green"
check_reset_prop "ro.boot.realme.lockstate" "1"

# Hide that we booted from recovery when magisk is in recovery mode
contains_reset_prop "ro.bootmode" "recovery" "unknown"
contains_reset_prop "ro.boot.bootmode" "recovery" "unknown"
contains_reset_prop "vendor.boot.bootmode" "recovery" "unknown"
