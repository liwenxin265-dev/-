#!/system/bin/sh

rm -f /data/adb/post-fs-data.d/auditpatch.sh