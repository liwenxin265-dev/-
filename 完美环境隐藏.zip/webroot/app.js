(function () {
    "use strict";

    // =========================================================
    // 基础路径
    // =========================================================

    var MODDIR = "/data/adb/modules/ksu-batch-modules";

    var NOTICE_SH = MODDIR + "/notice.sh";

    var ACTION_SH = MODDIR + "/action.sh";

    var RESULT_FILE = MODDIR + "/.notice/result";

    var NOTICE_FILE = MODDIR + "/.notice/notice.txt";

    var UPDATE_STATUS =
        MODDIR + "/.notice/update_status";


    // =========================================================
    // 状态
    // =========================================================

    var checking = false;

    var updating = false;

    var updateTimer = null;


    // =========================================================
    // DOM
    // =========================================================

    function $(id) {
        return document.getElementById(id);
    }


    function setText(id, value) {

        var node = $(id);

        if (!node) {
            return;
        }

        node.textContent =
            value == null
                ? ""
                : String(value);
    }


    function show(id) {

        var node = $(id);

        if (!node) {
            return;
        }

        node.classList.remove("hidden");
    }


    function hide(id) {

        var node = $(id);

        if (!node) {
            return;
        }

        node.classList.add("hidden");
    }


    // =========================================================
    // exec API
    // =========================================================

    function getExec() {

        if (
            window.ksu &&
            typeof window.ksu.exec === "function"
        ) {
            return window.ksu.exec.bind(window.ksu);
        }


        if (
            typeof window.exec === "function"
        ) {
            return window.exec;
        }


        return null;
    }


    function normalizeResult(result) {

        if (result == null) {
            return "";
        }


        if (typeof result === "string") {
            return result;
        }


        if (
            result.stdout &&
            typeof result.stdout === "string"
        ) {
            return result.stdout;
        }


        if (
            result.output &&
            typeof result.output === "string"
        ) {
            return result.output;
        }


        if (
            result.data &&
            typeof result.data === "string"
        ) {
            return result.data;
        }


        try {

            return JSON.stringify(result);

        } catch (e) {

            return String(result);
        }
    }


    function shellQuote(value) {

        return "'" +
            String(value)
                .replace(/'/g, "'\\''") +
            "'";
    }


    function exec(command, timeout) {

        return new Promise(function (
            resolve,
            reject
        ) {

            var fn = getExec();

            if (!fn) {

                reject(
                    new Error(
                        "SukiSU WebUI exec API 不可用"
                    )
                );

                return;
            }


            var finished = false;


            var timer = setTimeout(
                function () {

                    if (finished) {
                        return;
                    }

                    finished = true;

                    reject(
                        new Error(
                            "命令执行超时"
                        )
                    );

                },
                timeout || 10000
            );


            Promise.resolve()

                .then(function () {

                    return fn(command);

                })

                .then(function (result) {

                    if (finished) {
                        return;
                    }

                    finished = true;

                    clearTimeout(timer);

                    resolve(
                        normalizeResult(result)
                            .trim()
                    );

                })

                .catch(function (error) {

                    if (finished) {
                        return;
                    }

                    finished = true;

                    clearTimeout(timer);

                    reject(error);

                });

        });
    }


    // =========================================================
    // 读取 KEY=VALUE 文件
    // =========================================================

    async function getKVFile(
        file,
        key
    ) {

        try {

            var output = await exec(
                "grep '^" +
                shellQuote(key)
                    .slice(1, -1) +
                "=' " +
                shellQuote(file) +
                " 2>/dev/null | " +
                "head -n 1 | " +
                "cut -d= -f2-",
                5000
            );


            return output.trim();

        } catch (e) {

            return "";
        }
    }


    async function readStatus() {

        var output = "";

        try {

            output = await exec(
                "cat " +
                shellQuote(UPDATE_STATUS) +
                " 2>/dev/null",
                5000
            );

        } catch (e) {

            return {};
        }


        var result = {};

        output
            .split(/\r?\n/)
            .forEach(function (line) {

                var index =
                    line.indexOf("=");

                if (index <= 0) {
                    return;
                }


                var key =
                    line.slice(0, index);

                var value =
                    line.slice(index + 1);


                result[key] = value;
            });


        return result;
    }


    // =========================================================
    // 读取普通公告
    // =========================================================

    async function getNotice() {

        try {

            var encoded = await exec(
                "if [ -s " +
                shellQuote(NOTICE_FILE) +
                " ]; then " +
                "base64 " +
                shellQuote(NOTICE_FILE) +
                " 2>/dev/null | tr -d '\\n\\r'; " +
                "fi",
                5000
            );


            if (!encoded) {
                return "";
            }


            var binary =
                atob(encoded);


            var bytes =
                new Uint8Array(
                    binary.length
                );


            for (
                var i = 0;
                i < binary.length;
                i++
            ) {
                bytes[i] =
                    binary.charCodeAt(i);
            }


            if (
                window.TextDecoder
            ) {

                return new TextDecoder(
                    "utf-8"
                ).decode(bytes);
            }


            return decodeURIComponent(
                Array.prototype
                    .map
                    .call(
                        bytes,
                        function (byte) {

                            return "%" +
                                ("00" +
                                    byte.toString(16)
                                ).slice(-2);
                        }
                    )
                    .join("")
            );

        } catch (e) {

            return "";
        }
    }


    // =========================================================
    // UI 状态
    // =========================================================

    function setStatus(
        title,
        detail,
        type
    ) {

        setText(
            "status",
            title
        );


        setText(
            "status-detail",
            detail
        );


        var dot =
            $("status-dot");


        if (!dot) {
            return;
        }


        dot.className =
            "status-dot " +
            (type || "");
    }


    // =========================================================
    // 普通公告已读
    // =========================================================

    function noticeKey(text) {

        try {

            return (
                "sukisu_notice_seen_" +
                btoa(
                    unescape(
                        encodeURIComponent(text)
                    )
                ).slice(0, 120)
            );

        } catch (e) {

            return "sukisu_notice_seen";
        }
    }


    function noticeSeen(text) {

        try {

            return (
                localStorage.getItem(
                    noticeKey(text)
                ) === "1"
            );

        } catch (e) {

            return false;
        }
    }


    function markNoticeSeen(text) {

        try {

            localStorage.setItem(
                noticeKey(text),
                "1"
            );

        } catch (e) {}
    }


    // =========================================================
    // 强制更新弹窗
    // =========================================================

    function openForceUpdate(
        version,
        description
    ) {

        setText(
            "force-version",
            version || "--"
        );


        setText(
            "force-desc",
            description ||
                "检测到新的模块版本，请完成更新。"
        );


        show("force-modal");

        document.body.style.overflow =
            "hidden";
    }


    function closeForceUpdate() {

        hide("force-modal");

        document.body.style.overflow =
            "";
    }


    // =========================================================
    // 普通公告
    // =========================================================

    async function loadNotice() {

        var notice =
            await getNotice();


        if (!notice) {
            return;
        }


        setText(
            "notice-text",
            notice
        );


        show("notice-card");


        if (!noticeSeen(notice)) {

            markNoticeSeen(notice);

            // 普通公告直接显示卡片，
            // 不再阻塞强制更新。
        }
    }


    // =========================================================
    // 检查公告
    // =========================================================

    async function check() {

        if (checking || updating) {
            return;
        }


        checking = true;


        hide("error-panel");


        setStatus(
            "正在检查更新",
            "正在连接 GitHub 更新源…",
            "loading"
        );


        var api =
            getExec();


        setText(
            "api-info",
            api
                ? "exec：可用"
                : "exec：不可用"
        );


        if (!api) {

            setStatus(
                "检查失败",
                "当前 WebUI 不支持命令执行",
                "error"
            );


            setText(
                "error-text",
                "找不到 window.ksu.exec / window.exec"
            );


            show("error-panel");

            checking = false;

            return;
        }


        try {

            // -------------------------------------------------
            // 执行 notice.sh
            //
            // 如果你的 notice.sh 已经改成 GitHub 版本，
            // 这里直接使用。
            // -------------------------------------------------

            await exec(
                "sh " +
                shellQuote(NOTICE_SH) +
                " >/dev/null 2>&1",
                75000
            );


            var status =
                await getKVFile(
                    RESULT_FILE,
                    "STATUS"
                );


            var localVersion =
                await getKVFile(
                    RESULT_FILE,
                    "LOCAL_VERSION"
                );


            var remoteVersion =
                await getKVFile(
                    RESULT_FILE,
                    "REMOTE_VERSION"
                );


            var remoteVersionCode =
                await getKVFile(
                    RESULT_FILE,
                    "REMOTE_VERSIONCODE"
                );


            var forceUpdate =
                await getKVFile(
                    RESULT_FILE,
                    "FORCE_UPDATE"
                );


            var forceDesc =
                await getKVFile(
                    RESULT_FILE,
                    "FORCE_DESC"
                );


            var error =
                await getKVFile(
                    RESULT_FILE,
                    "ERROR"
                );


            setText(
                "local-version",
                localVersion || "--"
            );


            setText(
                "remote-version",
                remoteVersion || "--"
            );


            setText(
                "remote-versioncode",
                remoteVersionCode || "--"
            );


            // -------------------------------------------------
            // notice.sh 失败
            // -------------------------------------------------

            if (
                status &&
                status !== "OK"
            ) {

                setStatus(
                    "更新检查失败",
                    error ||
                        "远程更新信息读取失败",
                    "error"
                );


                setText(
                    "error-text",
                    "STATUS=" +
                    (status || "(空)") +
                    "\nERROR=" +
                    (error || "(空)")
                );


                show("error-panel");

                return;
            }


            setStatus(
                "检查完成",
                "GitHub 更新源连接正常",
                "ok"
            );


            // -------------------------------------------------
            // 普通公告
            // -------------------------------------------------

            await loadNotice();


            // -------------------------------------------------
            // 强制更新
            // -------------------------------------------------

            if (
                forceUpdate === "1"
            ) {

                openForceUpdate(
                    remoteVersion,
                    forceDesc
                );

            } else {

                hide("force-modal");
            }


        } catch (e) {

            var message =
                e &&
                e.message
                    ? e.message
                    : String(e);


            setStatus(
                "检查失败",
                message,
                "error"
            );


            setText(
                "error-text",
                message
            );


            show("error-panel");

        } finally {

            checking = false;
        }
    }


    // =========================================================
    // 更新进度
    // =========================================================

    function updateProgressUI(
        status
    ) {

        var progress =
            parseInt(
                status.PROGRESS || "0",
                10
            );


        if (
            isNaN(progress)
        ) {
            progress = 0;
        }


        progress =
            Math.max(
                0,
                Math.min(
                    100,
                    progress
                )
            );


        var bar =
            $("progress-bar");


        if (bar) {

            bar.style.width =
                progress + "%";
        }


        setText(
            "progress-percent",
            progress + "%"
        );


        setText(
            "progress-text",
            status.TEXT ||
                "正在更新…"
        );


        setText(
            "update-detail",
            status.ERROR ||
                ""
        );


        var stateText =
            "处理中";


        switch (status.STATUS) {

            case "STARTING":
                stateText = "准备中";
                break;

            case "CHECKING":
                stateText = "检查版本";
                break;

            case "DOWNLOADING":
                stateText = "下载中";
                break;

            case "VERIFYING":
                stateText = "验证中";
                break;

            case "EXTRACTING":
                stateText = "解压中";
                break;

            case "INSTALLING":
                stateText = "安装中";
                break;

            case "SUCCESS":
                stateText = "完成";
                break;

            case "NO_UPDATE":
                stateText = "无需更新";
                break;

            case "ERROR":
                stateText = "失败";
                break;
        }


        setText(
            "update-state",
            stateText
        );
    }


    // =========================================================
    // 停止监听
    // =========================================================

    function stopUpdateMonitor() {

        if (updateTimer) {

            clearInterval(
                updateTimer
            );

            updateTimer = null;
        }
    }


    // =========================================================
    // 开始监听
    // =========================================================

    function startUpdateMonitor() {

        stopUpdateMonitor();


        updateTimer =
            setInterval(
                async function () {

                    if (!updating) {
                        return;
                    }


                    var status =
                        await readStatus();


                    if (
                        !status ||
                        !status.STATUS
                    ) {
                        return;
                    }


                    updateProgressUI(
                        status
                    );


                    // -----------------------------------------
                    // 成功
                    // -----------------------------------------

                    if (
                        status.STATUS ===
                        "SUCCESS"
                    ) {

                        stopUpdateMonitor();

                        updating = false;

                        closeForceUpdate();

                        setText(
                            "success-text",
                            "模块已经成功更新到 " +
                            (
                                status.VERSION ||
                                "新版本"
                            ) +
                            "。\n\n" +
                            "请重启 SukiSU 使更新完全生效。"
                        );


                        show(
                            "success-modal"
                        );


                        return;
                    }


                    // -----------------------------------------
                    // 无需更新
                    // -----------------------------------------

                    if (
                        status.STATUS ===
                        "NO_UPDATE"
                    ) {

                        stopUpdateMonitor();

                        updating = false;

                        closeForceUpdate();

                        setStatus(
                            "当前已经是最新版本",
                            "无需重复下载。",
                            "ok"
                        );


                        hide(
                            "update-card"
                        );


                        return;
                    }


                    // -----------------------------------------
                    // 错误
                    // -----------------------------------------

                    if (
                        status.STATUS ===
                        "ERROR"
                    ) {

                        stopUpdateMonitor();

                        updating = false;


                        var errorText =
                            status.ERROR ||
                            status.TEXT ||
                            "未知错误";


                        setText(
                            "update-error-text",
                            errorText
                        );


                        show(
                            "error-modal"
                        );


                        return;
                    }

                },
                700
            );
    }


    // =========================================================
    // 开始更新
    // =========================================================

    async function startUpdate() {

        if (updating) {
            return;
        }


        updating = true;


        hide(
            "force-modal"
        );


        hide(
            "error-modal"
        );


        show(
            "update-card"
        );


        setStatus(
            "正在更新模块",
            "请不要关闭 WebUI…",
            "loading"
        );


        setText(
            "update-state",
            "准备中"
        );


        setText(
            "progress-text",
            "正在启动更新程序…"
        );


        setText(
            "progress-percent",
            "0%"
        );


        var bar =
            $("progress-bar");


        if (bar) {
            bar.style.width = "0%";
        }


        // -----------------------------------------------------
        // 清理旧状态
        // -----------------------------------------------------

        try {

            await exec(
                "rm -f " +
                shellQuote(
                    UPDATE_STATUS
                ),
                5000
            );

        } catch (e) {}


        // -----------------------------------------------------
        // 立即开始监听
        // -----------------------------------------------------

        startUpdateMonitor();


        // -----------------------------------------------------
        // 执行动作
        // -----------------------------------------------------

        try {

            await exec(
                "sh " +
                shellQuote(ACTION_SH) +
                " >/dev/null 2>&1",
                360000
            );

        } catch (e) {

            // action.sh 即使 exec 返回异常，
            // 仍然有可能已经成功完成。
            //
            // 所以这里不立即判定失败，
            // 交给 update_status 最终结果判断。
        }
    }


    // =========================================================
    // 重启 SukiSU
    // =========================================================

    async function restartSukiSU() {

        var button =
            $("restart-button");


        if (button) {
            button.disabled = true;
            button.textContent =
                "正在重启…";
        }


        try {

            // 自动寻找 SukiSU / KernelSU Manager
            // 不写死单一包名。

            var command =
                "PKG=$(pm list packages 2>/dev/null | " +
                "sed 's/^package://' | " +
                "grep -Ei " +
                "'sukisu|kernelsu' | " +
                "head -n 1); " +

                "if [ -n \"$PKG\" ]; then " +

                "am force-stop \"$PKG\" 2>/dev/null; " +

                "sleep 1; " +

                "monkey -p \"$PKG\" " +
                "-c android.intent.category.LAUNCHER " +
                "1 >/dev/null 2>&1; " +

                "else " +

                "echo SUKISU_PACKAGE_NOT_FOUND; " +

                "fi";


            await exec(
                command,
                15000
            );


        } catch (e) {

            if (button) {

                button.disabled = false;

                button.textContent =
                    "重启 SukiSU";
            }


            setText(
                "success-text",
                "模块已经更新成功。\n\n" +
                "但无法自动启动 SukiSU，" +
                "请手动重新打开 SukiSU。"
            );


            return;
        }
    }


    // =========================================================
    // 初始化
    // =========================================================

    function boot() {

        var refresh =
            $("refresh");


        if (refresh) {

            refresh.addEventListener(
                "click",
                check
            );
        }


        var updateButton =
            $("update-button");


        if (updateButton) {

            updateButton.addEventListener(
                "click",
                startUpdate
            );
        }


        var noticeClose =
            $("notice-close");


        if (noticeClose) {

            noticeClose.addEventListener(
                "click",
                function () {

                    var text =
                        $("notice-text")
                            ? $("notice-text")
                                .textContent
                            : "";


                    markNoticeSeen(
                        text
                    );


                    hide(
                        "notice-card"
                    );
                }
            );
        }


        var retry =
            $("retry-button");


        if (retry) {

            retry.addEventListener(
                "click",
                function () {

                    hide(
                        "error-modal"
                    );

                    startUpdate();
                }
            );
        }


        var errorClose =
            $("error-close");


        if (errorClose) {

            errorClose.addEventListener(
                "click",
                function () {

                    hide(
                        "error-modal"
                    );
                }
            );
        }


        var restart =
            $("restart-button");


        if (restart) {

            restart.addEventListener(
                "click",
                restartSukiSU
            );
        }


        var restartLater =
            $("restart-later");


        if (restartLater) {

            restartLater.addEventListener(
                "click",
                function () {

                    hide(
                        "success-modal"
                    );

                    setStatus(
                        "更新成功",
                        "请手动重启 SukiSU。",
                        "ok"
                    );
                }
            );
        }


        check();
    }


    if (
        document.readyState ===
        "loading"
    ) {

        document.addEventListener(
            "DOMContentLoaded",
            boot
        );

    } else {

        boot();
    }

})();