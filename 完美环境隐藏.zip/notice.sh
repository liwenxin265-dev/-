#!/system/bin/sh

# ============================================================
# SukiSU Batch Modules
# GitHub JSON 远程公告系统 v6.0
#
# 公告源：
# https://raw.githubusercontent.com/liwenxin265-dev/-/main/update.json
#
# 不再使用：
#   QQ 收藏
#   QQ HTML
#   HTML 清洗
#   OWNER
#   FORCE_URL
#
# JSON 字段：
#
# {
#   "id": "liwenxin265",
#   "version": "1.0.1",
#   "versionCode": 101,
#   "updateUrl": "https://...",
#
#   "notice": {
#     "enabled": true,
#     "id": "notice-001",
#     "title": "系统公告",
#     "content": "公告内容"
#   },
#
#   "forceUpdate": {
#     "enabled": true,
#     "title": "必须更新",
#     "content": "请立即更新"
#   },
#
#   "changelog": "更新日志"
# }
#
# 功能：
#   1. 每次打开 WebUI 都重新请求 JSON
#   2. 验证 JSON id
#   3. 比较本地 versionCode / 远程 versionCode
#   4. 检测强制更新
#   5. 检测普通公告
#   6. 普通公告关闭后 24 小时内不重复弹出
#   7. notice.id 改变后视为新公告
#   8. updateUrl 原样保存给 action.sh 使用
# ============================================================

MODDIR="${0%/*}"
STATE_DIR="$MODDIR/.notice"

RESULT_FILE="$STATE_DIR/result"
NOTICE_FILE="$STATE_DIR/notice.txt"
JSON_FILE="$STATE_DIR/update.json"

NOTICE_ID_FILE="$STATE_DIR/notice.id"
NOTICE_TIME_FILE="$STATE_DIR/notice.time"

REMOTE_ID_EXPECTED="liwenxin265"

UPDATE_JSON_URL="https://raw.githubusercontent.com/liwenxin265-dev/-/main/update.json"

# ============================================================
# 输出函数
# ============================================================

log() {
    echo "[→] $1"
}

ok() {
    echo "[✓] $1"
}

warn() {
    echo "[!] $1"
}

err() {
    echo "[✗] $1"
}

# ============================================================
# 初始化
# ============================================================

mkdir -p "$STATE_DIR" 2>/dev/null
chmod 0700 "$STATE_DIR" 2>/dev/null

rm -f "$RESULT_FILE"

# ============================================================
# 读取本地 module.prop
# ============================================================

echo ""
echo "========================================"
echo "       GitHub 公告解析 v6.0"
echo "========================================"
echo ""

log "读取 module.prop"

if [ ! -f "$MODDIR/module.prop" ]; then

    err "module.prop 不存在"

    printf '%s\n' "STATUS=ERROR" > "$RESULT_FILE"
    printf '%s\n' "ERROR=MODULE_PROP_NOT_FOUND" >> "$RESULT_FILE"

    exit 1

fi

LOCAL_VERSION="$(
    sed -n 's/^version=//p' "$MODDIR/module.prop" |
    head -n 1 |
    tr -d '\r'
)"

LOCAL_VERSIONCODE="$(
    sed -n 's/^versionCode=//p' "$MODDIR/module.prop" |
    head -n 1 |
    tr -d '\r'
)"

[ -n "$LOCAL_VERSION" ] || LOCAL_VERSION="0.0.0"
[ -n "$LOCAL_VERSIONCODE" ] || LOCAL_VERSIONCODE="0"

ok "本地版本：$LOCAL_VERSION"
ok "本地版本号：$LOCAL_VERSIONCODE"

# ============================================================
# 检查 curl
# ============================================================

log "查找 curl"

if command -v curl >/dev/null 2>&1; then

    CURL="$(command -v curl)"

elif [ -x /system/bin/curl ]; then

    CURL="/system/bin/curl"

elif [ -x /data/adb/ksu/bin/curl ]; then

    CURL="/data/adb/ksu/bin/curl"

else

    err "找不到 curl"

    printf '%s\n' "STATUS=ERROR" > "$RESULT_FILE"
    printf '%s\n' "ERROR=CURL_NOT_FOUND" >> "$RESULT_FILE"

    exit 1

fi

ok "curl：$CURL"

# ============================================================
# 下载 GitHub Raw JSON
# ============================================================

log "下载 GitHub update.json"

rm -f "$JSON_FILE"

"$CURL" \
    -L \
    --fail \
    --silent \
    --show-error \
    --connect-timeout 15 \
    --max-time 30 \
    -H "Accept: application/json" \
    -H "Cache-Control: no-cache" \
    -o "$JSON_FILE" \
    "$UPDATE_JSON_URL"

CURL_RET=$?

if [ "$CURL_RET" -ne 0 ] || [ ! -s "$JSON_FILE" ]; then

    err "update.json 下载失败"

    printf '%s\n' "STATUS=ERROR" > "$RESULT_FILE"
    printf '%s\n' "ERROR=UPDATE_JSON_DOWNLOAD_FAILED" >> "$RESULT_FILE"
    printf '%s\n' "LOCAL_VERSION=$LOCAL_VERSION" >> "$RESULT_FILE"
    printf '%s\n' "LOCAL_VERSIONCODE=$LOCAL_VERSIONCODE" >> "$RESULT_FILE"

    exit 1

fi

JSON_SIZE="$(
    wc -c < "$JSON_FILE" 2>/dev/null |
    tr -d ' '
)"

ok "update.json 下载成功：${JSON_SIZE} bytes"

# ============================================================
# 检查 jq
# ============================================================

log "检查 JSON 解析器"

if command -v jq >/dev/null 2>&1; then

    JQ="$(command -v jq)"

elif [ -x /system/bin/jq ]; then

    JQ="/system/bin/jq"

elif [ -x /data/adb/ksu/bin/jq ]; then

    JQ="/data/adb/ksu/bin/jq"

else

    JQ=""

fi

# ============================================================
# JSON 字符串提取
#
# 优先 jq。
#
# 如果系统没有 jq，使用极小的 awk/sed 兼容解析。
#
# 这里只解析我们自己的固定 JSON 字段。
# ============================================================

json_string() {

    KEY="$1"

    if [ -n "$JQ" ]; then

        "$JQ" -r --arg k "$KEY" '
            .[$k] // ""
        ' "$JSON_FILE" 2>/dev/null

        return

    fi

    sed -n \
        "s/.*\"$KEY\"[[:space:]]*:[[:space:]]*\"\([^\"]*\)\".*/\1/p" \
        "$JSON_FILE" |
        head -n 1

}

json_number() {

    KEY="$1"

    if [ -n "$JQ" ]; then

        "$JQ" -r --arg k "$KEY" '
            .[$k] // 0
        ' "$JSON_FILE" 2>/dev/null

        return

    fi

    sed -n \
        "s/.*\"$KEY\"[[:space:]]*:[[:space:]]*\([0-9][0-9]*\).*/\1/p" \
        "$JSON_FILE" |
        head -n 1

}

json_bool() {

    KEY="$1"

    if [ -n "$JQ" ]; then

        "$JQ" -r --arg k "$KEY" '
            if .[$k] == true then
                "true"
            else
                "false"
            end
        ' "$JSON_FILE" 2>/dev/null

        return

    fi

    sed -n \
        "s/.*\"$KEY\"[[:space:]]*:[[:space:]]*\(true\|false\).*/\1/p" \
        "$JSON_FILE" |
        head -n 1

}

# ============================================================
# 专门读取 notice / forceUpdate 对象
# ============================================================

json_nested_string() {

    OBJECT="$1"
    KEY="$2"

    if [ -n "$JQ" ]; then

        "$JQ" -r \
            --arg o "$OBJECT" \
            --arg k "$KEY" \
            '
            .[$o][$k] // ""
            ' \
            "$JSON_FILE" 2>/dev/null

        return

    fi

    awk -v object="$OBJECT" -v key="$KEY" '
        BEGIN {
            in_object=0
        }

        {
            if ($0 ~ "\"" object "\"[[:space:]]*:[[:space:]]*\\{") {
                in_object=1
            }

            if (in_object &&
                $0 ~ "\"" key "\"[[:space:]]*:[[:space:]]*\"") {

                line=$0

                sub(/^.*\"" key "\"[[:space:]]*:[[:space:]]*\"/, "", line)
                sub(/\"[[:space:]]*,?[[:space:]]*$/, "", line)

                print line
                exit
            }

            if (in_object && $0 ~ /^[[:space:]]*}/) {
                in_object=0
            }
        }
    ' "$JSON_FILE"

}

json_nested_bool() {

    OBJECT="$1"
    KEY="$2"

    if [ -n "$JQ" ]; then

        "$JQ" -r \
            --arg o "$OBJECT" \
            --arg k "$KEY" \
            '
            if .[$o][$k] == true then
                "true"
            else
                "false"
            end
            ' \
            "$JSON_FILE" 2>/dev/null

        return

    fi

    awk -v object="$OBJECT" -v key="$KEY" '
        BEGIN {
            in_object=0
        }

        {
            if ($0 ~ "\"" object "\"[[:space:]]*:[[:space:]]*\\{") {
                in_object=1
            }

            if (in_object &&
                $0 ~ "\"" key "\"[[:space:]]*:[[:space:]]*true") {

                print "true"
                exit
            }

            if (in_object &&
                $0 ~ "\"" key "\"[[:space:]]*:[[:space:]]*false") {

                print "false"
                exit
            }

            if (in_object && $0 ~ /^[[:space:]]*}/) {
                in_object=0
            }
        }
    ' "$JSON_FILE"

}

# ============================================================
# 读取顶层数据
# ============================================================

log "解析 JSON"

REMOTE_ID="$(
    json_string "id" |
    tr -d '\r\n'
)"

REMOTE_VERSION="$(
    json_string "version" |
    tr -d '\r\n'
)"

REMOTE_VERSIONCODE="$(
    json_number "versionCode" |
    tr -d '\r\n'
)"

UPDATE_URL="$(
    json_string "updateUrl" |
    tr -d '\r\n'
)"

CHANGELOG="$(
    json_string "changelog" |
    tr -d '\r\n'
)"

# ============================================================
# 验证远程身份
# ============================================================

if [ -z "$REMOTE_ID" ]; then

    err "JSON 中不存在 id"

    printf '%s\n' "STATUS=ERROR" > "$RESULT_FILE"
    printf '%s\n' "ERROR=REMOTE_ID_MISSING" >> "$RESULT_FILE"
    printf '%s\n' "LOCAL_VERSION=$LOCAL_VERSION" >> "$RESULT_FILE"
    printf '%s\n' "LOCAL_VERSIONCODE=$LOCAL_VERSIONCODE" >> "$RESULT_FILE"

    exit 1

fi

ok "远程 ID：$REMOTE_ID"

if [ "$REMOTE_ID" != "$REMOTE_ID_EXPECTED" ]; then

    err "远程公告源身份验证失败"
    err "预期：$REMOTE_ID_EXPECTED"
    err "实际：$REMOTE_ID"

    printf '%s\n' "STATUS=ID_INVALID" > "$RESULT_FILE"
    printf '%s\n' "ERROR=REMOTE_ID_INVALID" >> "$RESULT_FILE"
    printf '%s\n' "REMOTE_ID=$REMOTE_ID" >> "$RESULT_FILE"
    printf '%s\n' "LOCAL_VERSION=$LOCAL_VERSION" >> "$RESULT_FILE"
    printf '%s\n' "LOCAL_VERSIONCODE=$LOCAL_VERSIONCODE" >> "$RESULT_FILE"

    exit 1

fi

ok "远程 ID 验证通过"

# ============================================================
# 检查版本数据
# ============================================================

if [ -z "$REMOTE_VERSION" ]; then

    err "JSON 中不存在 version"

    printf '%s\n' "STATUS=ERROR" > "$RESULT_FILE"
    printf '%s\n' "ERROR=REMOTE_VERSION_MISSING" >> "$RESULT_FILE"
    printf '%s\n' "LOCAL_VERSION=$LOCAL_VERSION" >> "$RESULT_FILE"
    printf '%s\n' "LOCAL_VERSIONCODE=$LOCAL_VERSIONCODE" >> "$RESULT_FILE"

    exit 1

fi

case "$REMOTE_VERSIONCODE" in

    ''|*[!0-9]*)

        err "versionCode 无效：$REMOTE_VERSIONCODE"

        printf '%s\n' "STATUS=ERROR" > "$RESULT_FILE"
        printf '%s\n' "ERROR=REMOTE_VERSIONCODE_INVALID" >> "$RESULT_FILE"
        printf '%s\n' "LOCAL_VERSION=$LOCAL_VERSION" >> "$RESULT_FILE"
        printf '%s\n' "LOCAL_VERSIONCODE=$LOCAL_VERSIONCODE" >> "$RESULT_FILE"

        exit 1

        ;;

esac

ok "远程版本：$REMOTE_VERSION"
ok "远程版本号：$REMOTE_VERSIONCODE"

# ============================================================
# 比较版本
# ============================================================

FORCE_UPDATE=0

if [ "$REMOTE_VERSIONCODE" -gt "$LOCAL_VERSIONCODE" ] 2>/dev/null; then

    FORCE_UPDATE=1

    log "远程版本高于本地版本"
    ok "检测到版本更新"

else

    log "当前没有版本更新"

fi

# ============================================================
# 读取普通公告
# ============================================================

log "解析普通公告"

NOTICE_ENABLED="$(
    json_nested_bool "notice" "enabled" |
    tr -d '\r\n'
)"

NOTICE_ID="$(
    json_nested_string "notice" "id" |
    tr -d '\r\n'
)"

NOTICE_TITLE="$(
    json_nested_string "notice" "title" |
    tr -d '\r\n'
)"

NOTICE_CONTENT="$(
    json_nested_string "notice" "content" |
    tr -d '\r\n'
)"

if [ "$NOTICE_ENABLED" = "true" ] &&
   [ -n "$NOTICE_ID" ] &&
   [ -n "$NOTICE_CONTENT" ]; then

    ok "普通公告已启用"

else

    NOTICE_ENABLED="false"

    NOTICE_ID=""
    NOTICE_TITLE=""
    NOTICE_CONTENT=""

    log "当前没有启用普通公告"

fi

# ============================================================
# 保存普通公告内容
# ============================================================

if [ -n "$NOTICE_CONTENT" ]; then

    printf '%s\n' "$NOTICE_CONTENT" > "$NOTICE_FILE"

else

    : > "$NOTICE_FILE"

fi

# ============================================================
# 普通公告 24 小时判断
#
# 规则：
#
# 1. 第一次出现 → 显示
# 2. 用户关闭 → app.js 记录当前时间
# 3. 24 小时内 → 不弹
# 4. 超过 24 小时 → 再弹
# 5. notice.id 改变 → 新公告，立即弹
#
# 注意：
# notice.sh 只负责判断状态。
# 真正点击“关闭”的时间由 app.js 写入。
# ============================================================

SHOW_NOTICE=0

if [ "$NOTICE_ENABLED" = "true" ]; then

    LAST_NOTICE_ID=""

    LAST_NOTICE_TIME=""

    if [ -f "$NOTICE_ID_FILE" ]; then

        LAST_NOTICE_ID="$(
            head -n 1 "$NOTICE_ID_FILE" 2>/dev/null |
            tr -d '\r\n'
        )"

    fi

    if [ -f "$NOTICE_TIME_FILE" ]; then

        LAST_NOTICE_TIME="$(
            head -n 1 "$NOTICE_TIME_FILE" 2>/dev/null |
            tr -d '\r\n'
        )"

    fi

    NOW="$(date +%s 2>/dev/null)"

    # 新公告
    if [ "$LAST_NOTICE_ID" != "$NOTICE_ID" ]; then

        SHOW_NOTICE=1

        log "检测到新的普通公告"

    else

        # 同一个公告
        if [ -n "$LAST_NOTICE_TIME" ] &&
           [ -n "$NOW" ]; then

            DIFF=$((NOW - LAST_NOTICE_TIME))

            if [ "$DIFF" -ge 86400 ]; then

                SHOW_NOTICE=1

                log "普通公告关闭时间已超过 24 小时"

            else

                SHOW_NOTICE=0

                log "普通公告仍在 24 小时免打扰时间内"

            fi

        else

            SHOW_NOTICE=1

            log "没有找到普通公告关闭记录"

        fi

    fi

fi

# ============================================================
# 强制更新
# ============================================================

FORCE_TITLE="$(
    json_nested_string "forceUpdate" "title" |
    tr -d '\r\n'
)"

FORCE_DESC="$(
    json_nested_string "forceUpdate" "content" |
    tr -d '\r\n'
)"

FORCE_ENABLED="$(
    json_nested_bool "forceUpdate" "enabled" |
    tr -d '\r\n'
)"

# ============================================================
# 强制更新逻辑
#
# 只有：
#
#   versionCode > 本地 versionCode
#   AND
#   forceUpdate.enabled == true
#
# 才显示强制更新。
# ============================================================

if [ "$FORCE_UPDATE" = "1" ] &&
   [ "$FORCE_ENABLED" = "true" ]; then

    FORCE_UPDATE=1

    ok "强制更新已启用"

else

    FORCE_UPDATE=0

fi

# ============================================================
# 更新链接检查
#
# 这里只检查有没有值。
# 不解析、不修改、不截断 URL。
# ============================================================

if [ -n "$UPDATE_URL" ]; then

    ok "更新链接已读取"

else

    if [ "$FORCE_UPDATE" = "1" ]; then

        warn "强制更新存在，但 updateUrl 为空"

    fi

fi

# ============================================================
# 写入 result
# ============================================================

log "写入 result"

{
    printf '%s\n' "STATUS=OK"

    printf '%s\n' "REMOTE_ID=$REMOTE_ID"

    printf '%s\n' "LOCAL_VERSION=$LOCAL_VERSION"
    printf '%s\n' "LOCAL_VERSIONCODE=$LOCAL_VERSIONCODE"

    printf '%s\n' "REMOTE_VERSION=$REMOTE_VERSION"
    printf '%s\n' "REMOTE_VERSIONCODE=$REMOTE_VERSIONCODE"

    printf '%s\n' "FORCE_UPDATE=$FORCE_UPDATE"
    printf '%s\n' "FORCE_VERSION=$REMOTE_VERSION"
    printf '%s\n' "FORCE_VERSIONCODE=$REMOTE_VERSIONCODE"

    printf '%s\n' "UPDATE_URL=$UPDATE_URL"

    printf '%s\n' "FORCE_TITLE=$FORCE_TITLE"
    printf '%s\n' "FORCE_DESC=$FORCE_DESC"

    printf '%s\n' "NOTICE_ENABLED=$NOTICE_ENABLED"
    printf '%s\n' "NOTICE_ID=$NOTICE_ID"
    printf '%s\n' "NOTICE_TITLE=$NOTICE_TITLE"
    printf '%s\n' "SHOW_NOTICE=$SHOW_NOTICE"

    printf '%s\n' "CHANGELOG=$CHANGELOG"

} > "$RESULT_FILE"

chmod 0600 "$RESULT_FILE" 2>/dev/null
chmod 0600 "$NOTICE_FILE" 2>/dev/null

# ============================================================
# 最终输出
# ============================================================

ok "全部解析完成"

echo ""
echo "========================================"
echo "             v6.0 完成"
echo "========================================"

cat "$RESULT_FILE"

echo ""

exit 0