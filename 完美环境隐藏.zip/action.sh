#!/system/bin/sh

# ============================================================
# SukiSU Batch Modules
# action.sh
#
# GitHub 远程更新程序
#
# 功能：
#   1. 读取 GitHub update.json
#   2. 校验远程 ID
#   3. 对比本地 / 远程 versionCode
#   4. 下载 ZIP
#   5. 显示实时下载进度
#   6. 验证 ZIP
#   7. 验证 module.prop
#   8. 覆盖安装模块
#   9. 写入 update_status
#
# 注意：
#   本脚本不会自行重启设备。
#   更新成功后由 app.js 弹出重启 SukiSU 对话框。
# ============================================================

MODDIR="/data/adb/modules/ksu-batch-modules"
STATE_DIR="$MODDIR/.notice"

STATUS_FILE="$STATE_DIR/update_status"
LOCK_FILE="$STATE_DIR/update.lock"

TMP_DIR="/data/local/tmp/ksu-batch-update"
JSON_FILE="$TMP_DIR/update.json"
ZIP_FILE="$TMP_DIR/module.zip"
EXTRACT_DIR="$TMP_DIR/extract"

# ============================================================
# GitHub update.json
# ============================================================

UPDATE_JSON_URL="https://raw.githubusercontent.com/liwenxin265-dev/-/main/update.json"

# 你的远程身份 ID
EXPECTED_ID="liwenxin265"

# ============================================================
# 基础函数
# ============================================================

write_status() {
    mkdir -p "$STATE_DIR"

    STATUS="$1"
    PROGRESS="$2"
    TEXT="$3"
    ERROR="$4"
    VERSION="$5"

    {
        printf '%s\n' "STATUS=$STATUS"
        printf '%s\n' "PROGRESS=$PROGRESS"
        printf '%s\n' "TEXT=$TEXT"

        if [ -n "$ERROR" ]; then
            printf '%s\n' "ERROR=$ERROR"
        fi

        if [ -n "$VERSION" ]; then
            printf '%s\n' "VERSION=$VERSION"
        fi

        printf '%s\n' "TIME=$(date +%s 2>/dev/null)"
    } > "$STATUS_FILE.tmp"

    mv -f "$STATUS_FILE.tmp" "$STATUS_FILE"
}

log() {
    echo "[→] $1"
}

ok() {
    echo "[✓] $1"
}

err() {
    echo "[✗] $1"
}

cleanup() {
    rm -f "$LOCK_FILE"

    # 成功以后不马上删除，方便诊断
    if [ "$KEEP_TMP" != "1" ]; then
        rm -rf "$TMP_DIR"
    fi
}

fail() {
    MESSAGE="$1"
    CODE="$2"

    err "$MESSAGE"

    write_status \
        "ERROR" \
        "0" \
        "$MESSAGE" \
        "$CODE" \
        "$REMOTE_VERSION"

    cleanup

    exit 1
}

trap cleanup EXIT

# ============================================================
# 防止重复执行
# ============================================================

mkdir -p "$STATE_DIR"

if [ -f "$LOCK_FILE" ]; then
    OLD_PID="$(cat "$LOCK_FILE" 2>/dev/null)"

    if [ -n "$OLD_PID" ] &&
       kill -0 "$OLD_PID" 2>/dev/null; then

        echo "[!] 更新程序已经在运行"
        exit 0
    fi

    rm -f "$LOCK_FILE"
fi

echo "$$" > "$LOCK_FILE"

# ============================================================
# 初始化
# ============================================================

KEEP_TMP="0"

rm -rf "$TMP_DIR"

if ! mkdir -p "$TMP_DIR"; then
    fail "无法创建临时目录" "TMP_CREATE_FAILED"
fi

chmod 0700 "$TMP_DIR" 2>/dev/null

write_status \
    "STARTING" \
    "0" \
    "正在准备更新…" \
    "" \
    ""

echo ""
echo "========================================"
echo "       SukiSU Batch Modules"
echo "          GitHub 远程更新"
echo "========================================"
echo ""

# ============================================================
# 1. Root
# ============================================================

log "检查 ROOT 权限"

if [ "$(id -u 2>/dev/null)" != "0" ]; then
    fail "当前不是 ROOT 环境" "ROOT_REQUIRED"
fi

ok "ROOT 权限正常"

# ============================================================
# 2. 模块目录
# ============================================================

log "检查模块目录"

if [ ! -d "$MODDIR" ]; then
    fail "模块目录不存在：$MODDIR" "MODULE_DIR_NOT_FOUND"
fi

if [ ! -f "$MODDIR/module.prop" ]; then
    fail "module.prop 不存在" "MODULE_PROP_NOT_FOUND"
fi

ok "模块目录正常"

# ============================================================
# 3. curl
# ============================================================

log "检查 curl"

if command -v curl >/dev/null 2>&1; then
    CURL="$(command -v curl)"
elif [ -x "/data/adb/ksu/bin/curl" ]; then
    CURL="/data/adb/ksu/bin/curl"
else
    fail "找不到 curl" "CURL_NOT_FOUND"
fi

ok "curl：$CURL"

# ============================================================
# 4. unzip
# ============================================================

log "检查 unzip"

if command -v unzip >/dev/null 2>&1; then
    UNZIP="$(command -v unzip)"
else
    fail "找不到 unzip" "UNZIP_NOT_FOUND"
fi

ok "unzip：$UNZIP"

# ============================================================
# 5. 读取本地 module.prop
# ============================================================

log "读取本地版本"

LOCAL_ID="$(
    sed -n 's/^id=//p' "$MODDIR/module.prop" |
    head -n 1 |
    tr -d '\r'
)"

LOCAL_VERSION="$(
    sed -n 's/^version=//p' "$MODDIR/module.prop" |
    head -n 1 |
    tr -d '\r'
)"

LOCAL_VERSIONCODE="$(
    sed -n 's/^versionCode=//p' "$MODDIR/module.prop" |
    head -n 1 |
    tr -d '\r'
)"

[ -n "$LOCAL_ID" ] || LOCAL_ID="ksu-batch-modules"
[ -n "$LOCAL_VERSION" ] || LOCAL_VERSION="0.0.0"
[ -n "$LOCAL_VERSIONCODE" ] || LOCAL_VERSIONCODE="0"

ok "本地 ID：$LOCAL_ID"
ok "本地版本：$LOCAL_VERSION"
ok "本地版本号：$LOCAL_VERSIONCODE"

# ============================================================
# 6. 下载 update.json
# ============================================================

write_status \
    "CHECKING" \
    "5" \
    "正在读取 GitHub 更新信息…" \
    "" \
    ""

echo ""
log "下载 GitHub update.json"

rm -f "$JSON_FILE"

"$CURL" \
    -L \
    --fail \
    --silent \
    --show-error \
    --connect-timeout 15 \
    --max-time 30 \
    -A "SukiSU-Batch-Modules-Updater" \
    "$UPDATE_JSON_URL" \
    -o "$JSON_FILE"

RET=$?

if [ "$RET" -ne 0 ] || [ ! -s "$JSON_FILE" ]; then
    fail "无法获取 GitHub update.json" "JSON_DOWNLOAD_FAILED"
fi

ok "update.json 获取成功"

# ============================================================
# 7. 简单 JSON 字段提取
#
# update.json 不使用复杂嵌套。
#
# 推荐格式：
#
# {
#   "id": "liwenxin265",
#   "version": "1.2.0",
#   "versionCode": 120,
#   "download_url": "https://...",
#   "force_update": true,
#   "notice": "...",
#   "update_description": "..."
# }
#
# ============================================================

json_string() {
    KEY="$1"

    sed -n \
        "s/.*\"$KEY\"[[:space:]]*:[[:space:]]*\"\\([^\"]*\\)\".*/\1/p" \
        "$JSON_FILE" |
        head -n 1 |
        tr -d '\r'
}

json_number() {
    KEY="$1"

    sed -n \
        "s/.*\"$KEY\"[[:space:]]*:[[:space:]]*\\([0-9][0-9]*\\).*/\1/p" \
        "$JSON_FILE" |
        head -n 1 |
        tr -d '\r'
}

json_bool() {
    KEY="$1"

    sed -n \
        "s/.*\"$KEY\"[[:space:]]*:[[:space:]]*\\(true\\|false\\).*/\1/p" \
        "$JSON_FILE" |
        head -n 1 |
        tr -d '\r'
}

REMOTE_ID="$(json_string "id")"
REMOTE_VERSION="$(json_string "version")"
REMOTE_VERSIONCODE="$(json_number "versionCode")"
DOWNLOAD_URL="$(json_string "download_url")"
FORCE_UPDATE="$(json_bool "force_update")"
REMOTE_NOTICE="$(json_string "notice")"
UPDATE_DESC="$(json_string "update_description")"

# ============================================================
# 8. 检查远程 JSON
# ============================================================

if [ -z "$REMOTE_ID" ]; then
    fail "update.json 缺少 id" "REMOTE_ID_MISSING"
fi

if [ "$REMOTE_ID" != "$EXPECTED_ID" ]; then
    fail "远程 ID 校验失败：$REMOTE_ID" "REMOTE_ID_MISMATCH"
fi

ok "远程 ID：$REMOTE_ID"

if [ -z "$REMOTE_VERSION" ]; then
    fail "update.json 缺少 version" "REMOTE_VERSION_MISSING"
fi

if [ -z "$REMOTE_VERSIONCODE" ]; then
    fail "update.json 缺少 versionCode" "REMOTE_VERSIONCODE_MISSING"
fi

case "$REMOTE_VERSIONCODE" in
    *[!0-9]*)
        fail "远程 versionCode 无效" "REMOTE_VERSIONCODE_INVALID"
        ;;
esac

ok "远程版本：$REMOTE_VERSION"
ok "远程版本号：$REMOTE_VERSIONCODE"

# ============================================================
# 9. 版本比较
# ============================================================

write_status \
    "CHECKING" \
    "10" \
    "正在比较本地与远程版本…" \
    "" \
    "$REMOTE_VERSION"

if [ "$REMOTE_VERSIONCODE" -le "$LOCAL_VERSIONCODE" ] 2>/dev/null; then

    ok "当前已经是最新版本"

    write_status \
        "NO_UPDATE" \
        "100" \
        "当前已经是最新版本，无需重复下载。" \
        "" \
        "$REMOTE_VERSION"

    exit 0
fi

ok "发现新版本：$REMOTE_VERSION"

# ============================================================
# 10. 下载地址
# ============================================================

if [ -z "$DOWNLOAD_URL" ]; then
    fail "update.json 没有 download_url" "DOWNLOAD_URL_MISSING"
fi

case "$DOWNLOAD_URL" in
    https://*)
        ;;
    *)
        fail "更新地址必须使用 HTTPS" "DOWNLOAD_URL_INVALID"
        ;;
esac

# ============================================================
# 11. 开始下载
# ============================================================

write_status \
    "DOWNLOADING" \
    "15" \
    "正在下载模块 $REMOTE_VERSION…" \
    "" \
    "$REMOTE_VERSION"

echo ""
log "开始下载模块"
echo "[→] 远程版本：$REMOTE_VERSION"
echo "[→] 远程版本号：$REMOTE_VERSIONCODE"
echo ""

rm -f "$ZIP_FILE"

# ============================================================
# curl 进度
#
# 使用临时文件保存 curl 输出。
# 同时通过一个后台进程读取文件并更新 STATUS。
# ============================================================

PROGRESS_FILE="$TMP_DIR/progress"

rm -f "$PROGRESS_FILE"

(
    "$CURL" \
        -L \
        --fail \
        --show-error \
        --connect-timeout 20 \
        --max-time 300 \
        -A "SukiSU-Batch-Modules-Updater" \
        -o "$ZIP_FILE" \
        "$DOWNLOAD_URL" \
        2> "$TMP_DIR/curl.log"

    echo "$?" > "$TMP_DIR/curl.exit"
) &

DOWNLOAD_PID=$!

LAST_PROGRESS=-1

while kill -0 "$DOWNLOAD_PID" 2>/dev/null; do

    if [ -f "$ZIP_FILE" ]; then

        CURRENT_SIZE="$(
            wc -c < "$ZIP_FILE" 2>/dev/null |
            tr -d ' '
        )"

        case "$CURRENT_SIZE" in
            ''|*[!0-9]*)
                CURRENT_SIZE=0
                ;;
        esac

        # update.json / HTTP Content-Length 如果无法获取，
        # 这里使用动态下载状态，不伪造百分比。
        #
        # 状态文件中的 PROGRESS=15 表示正在下载。
        # 页面会显示“已下载 X MB”。

        MB=$((CURRENT_SIZE / 1024 / 1024))

        write_status \
            "DOWNLOADING" \
            "15" \
            "正在下载模块… 已下载 ${MB} MB" \
            "" \
            "$REMOTE_VERSION"
    fi

    sleep 1
done

wait "$DOWNLOAD_PID" 2>/dev/null

DOWNLOAD_RET=0

if [ -f "$TMP_DIR/curl.exit" ]; then
    DOWNLOAD_RET="$(cat "$TMP_DIR/curl.exit" 2>/dev/null)"
fi

if [ "$DOWNLOAD_RET" != "0" ] ||
   [ ! -s "$ZIP_FILE" ]; then

    ERROR_DETAIL="DOWNLOAD_FAILED"

    if [ -s "$TMP_DIR/curl.log" ]; then
        ERROR_DETAIL="$(tail -n 1 "$TMP_DIR/curl.log" 2>/dev/null)"
    fi

    fail "模块下载失败：$ERROR_DETAIL" "DOWNLOAD_FAILED"
fi

ZIP_SIZE="$(
    wc -c < "$ZIP_FILE" 2>/dev/null |
    tr -d ' '
)"

ok "下载完成：${ZIP_SIZE} bytes"

write_status \
    "VERIFYING" \
    "60" \
    "下载完成，正在验证模块包…" \
    "" \
    "$REMOTE_VERSION"

# ============================================================
# 12. ZIP 验证
# ============================================================

log "验证 ZIP"

if ! "$UNZIP" -t "$ZIP_FILE" >/dev/null 2>&1; then
    fail "ZIP 文件损坏或格式无效" "ZIP_INVALID"
fi

ok "ZIP 完整性验证通过"

# ============================================================
# 13. 解压
# ============================================================

write_status \
    "EXTRACTING" \
    "65" \
    "正在解压模块…" \
    "" \
    "$REMOTE_VERSION"

rm -rf "$EXTRACT_DIR"

if ! mkdir -p "$EXTRACT_DIR"; then
    fail "无法创建解压目录" "EXTRACT_DIR_FAILED"
fi

if ! "$UNZIP" \
    -q \
    "$ZIP_FILE" \
    -d "$EXTRACT_DIR"; then

    fail "模块解压失败" "UNZIP_FAILED"
fi

ok "模块解压完成"

# ============================================================
# 14. 定位 module.prop
# ============================================================

REMOTE_PROP=""

if [ -f "$EXTRACT_DIR/module.prop" ]; then
    REMOTE_PROP="$EXTRACT_DIR/module.prop"
else
    REMOTE_PROP="$(
        find "$EXTRACT_DIR" \
            -type f \
            -name module.prop \
            2>/dev/null |
        head -n 1
    )"
fi

if [ -z "$REMOTE_PROP" ] ||
   [ ! -f "$REMOTE_PROP" ]; then

    fail "ZIP 中没有找到 module.prop" "REMOTE_MODULE_PROP_MISSING"
fi

REMOTE_PACKAGE_ID="$(
    sed -n 's/^id=//p' "$REMOTE_PROP" |
    head -n 1 |
    tr -d '\r'
)"

REMOTE_PACKAGE_VERSION="$(
    sed -n 's/^version=//p' "$REMOTE_PROP" |
    head -n 1 |
    tr -d '\r'
)"

REMOTE_PACKAGE_VERSIONCODE="$(
    sed -n 's/^versionCode=//p' "$REMOTE_PROP" |
    head -n 1 |
    tr -d '\r'
)"

# ============================================================
# 15. 验证 ZIP 内模块身份
# ============================================================

if [ "$REMOTE_PACKAGE_ID" != "$LOCAL_ID" ]; then
    fail \
        "模块 ID 不匹配：$REMOTE_PACKAGE_ID" \
        "MODULE_ID_MISMATCH"
fi

ok "模块 ID 验证通过：$REMOTE_PACKAGE_ID"

if [ -n "$REMOTE_PACKAGE_VERSIONCODE" ]; then

    case "$REMOTE_PACKAGE_VERSIONCODE" in
        *[!0-9]*)
            fail "ZIP 内 versionCode 无效" "PACKAGE_VERSIONCODE_INVALID"
            ;;
    esac

    if [ "$REMOTE_PACKAGE_VERSIONCODE" -lt "$REMOTE_VERSIONCODE" ] 2>/dev/null; then
        fail \
            "ZIP 内版本号低于 update.json" \
            "PACKAGE_VERSIONCODE_MISMATCH"
    fi
fi

# ============================================================
# 16. 查找真正的模块根目录
# ============================================================

PACKAGE_ROOT="$EXTRACT_DIR"

if [ ! -f "$PACKAGE_ROOT/module.prop" ]; then

    FOUND_PROP_DIR="$(
        dirname "$REMOTE_PROP"
    )"

    PACKAGE_ROOT="$FOUND_PROP_DIR"
fi

if [ ! -f "$PACKAGE_ROOT/module.prop" ]; then
    fail "无法确定模块根目录" "PACKAGE_ROOT_INVALID"
fi

# ============================================================
# 17. 创建安装暂存区
# ============================================================

INSTALL_DIR="$TMP_DIR/install"

rm -rf "$INSTALL_DIR"

if ! mkdir -p "$INSTALL_DIR"; then
    fail "无法创建安装暂存目录" "INSTALL_DIR_FAILED"
fi

write_status \
    "INSTALLING" \
    "75" \
    "正在准备安装模块…" \
    "" \
    "$REMOTE_VERSION"

# ============================================================
# 18. 复制模块
# ============================================================

if ! cp -af "$PACKAGE_ROOT"/. "$INSTALL_DIR"/; then
    fail "无法准备模块文件" "COPY_PREPARE_FAILED"
fi

# ============================================================
# 19. 再次确认 module.prop
# ============================================================

if [ ! -f "$INSTALL_DIR/module.prop" ]; then
    fail "安装包缺少 module.prop" "INSTALL_PROP_MISSING"
fi

INSTALL_ID="$(
    sed -n 's/^id=//p' "$INSTALL_DIR/module.prop" |
    head -n 1 |
    tr -d '\r'
)"

if [ "$INSTALL_ID" != "$LOCAL_ID" ]; then
    fail "安装包 ID 校验失败" "INSTALL_ID_MISMATCH"
fi

# ============================================================
# 20. 备份当前模块
# ============================================================

BACKUP_DIR="/data/local/tmp/ksu-batch-update-backup"

rm -rf "$BACKUP_DIR"

if ! mkdir -p "$BACKUP_DIR"; then
    fail "无法创建模块备份目录" "BACKUP_FAILED"
fi

write_status \
    "INSTALLING" \
    "80" \
    "正在备份当前模块…" \
    "" \
    "$REMOTE_VERSION"

if ! cp -af "$MODDIR"/. "$BACKUP_DIR"/; then
    rm -rf "$BACKUP_DIR"
    fail "当前模块备份失败，安装已中止" "BACKUP_COPY_FAILED"
fi

ok "当前模块备份完成"

# ============================================================
# 21. 保留本地状态目录
#
# .notice 不能被远程 ZIP 覆盖。
# ============================================================

LOCAL_STATE_BACKUP="$TMP_DIR/local_notice"

rm -rf "$LOCAL_STATE_BACKUP"

if [ -d "$STATE_DIR" ]; then
    cp -af "$STATE_DIR" "$LOCAL_STATE_BACKUP"
fi

# ============================================================
# 22. 清理当前模块文件
# ============================================================

write_status \
    "INSTALLING" \
    "85" \
    "正在安装新版本…" \
    "" \
    "$REMOTE_VERSION"

# 删除当前模块中的普通文件。
#
# 保留：
#   .notice
#   update_status
#   update.lock
#
# 避免删除 action.sh 当前正在运行所需要的文件，
# 所以先把安装文件复制进去。

find "$MODDIR" \
    -mindepth 1 \
    -maxdepth 1 \
    ! -name ".notice" \
    -exec rm -rf {} \; 2>/dev/null

# ============================================================
# 23. 覆盖安装
# ============================================================

if ! cp -af "$INSTALL_DIR"/. "$MODDIR"/; then

    err "覆盖安装失败"

    # 尝试恢复
    find "$MODDIR" \
        -mindepth 1 \
        -maxdepth 1 \
        ! -name ".notice" \
        -exec rm -rf {} \; 2>/dev/null

    cp -af "$BACKUP_DIR"/. "$MODDIR"/ 2>/dev/null

    fail "模块安装失败，已尝试恢复旧版本" "INSTALL_COPY_FAILED"
fi

ok "模块文件覆盖完成"

# ============================================================
# 24. 恢复 .notice
# ============================================================

if [ -d "$LOCAL_STATE_BACKUP" ]; then

    rm -rf "$MODDIR/.notice"

    if ! cp -af "$LOCAL_STATE_BACKUP" "$MODDIR/.notice"; then
        fail "恢复本地状态目录失败" "STATE_RESTORE_FAILED"
    fi
fi

# ============================================================
# 25. 最终 module.prop 检查
# ============================================================

if [ ! -f "$MODDIR/module.prop" ]; then
    fail "安装后 module.prop 不存在" "FINAL_PROP_MISSING"
fi

FINAL_ID="$(
    sed -n 's/^id=//p' "$MODDIR/module.prop" |
    head -n 1 |
    tr -d '\r'
)"

FINAL_VERSION="$(
    sed -n 's/^version=//p' "$MODDIR/module.prop" |
    head -n 1 |
    tr -d '\r'
)"

FINAL_VERSIONCODE="$(
    sed -n 's/^versionCode=//p' "$MODDIR/module.prop" |
    head -n 1 |
    tr -d '\r'
)"

if [ "$FINAL_ID" != "$LOCAL_ID" ]; then
    fail "安装后的模块 ID 错误" "FINAL_ID_MISMATCH"
fi

if [ -z "$FINAL_VERSIONCODE" ]; then
    fail "安装后的 versionCode 不存在" "FINAL_VERSIONCODE_MISSING"
fi

if [ "$FINAL_VERSIONCODE" -lt "$REMOTE_VERSIONCODE" ] 2>/dev/null; then
    fail "安装后的版本号异常" "FINAL_VERSIONCODE_INVALID"
fi

# ============================================================
# 26. 权限
# ============================================================

chmod 0755 "$MODDIR"/*.sh 2>/dev/null
chmod 0700 "$MODDIR/.notice" 2>/dev/null

# ============================================================
# 27. 清理备份
# ============================================================

rm -rf "$BACKUP_DIR"

# ============================================================
# 28. 更新成功
# ============================================================

write_status \
    "SUCCESS" \
    "100" \
    "模块更新成功，现在可以重启 SukiSU。" \
    "" \
    "$FINAL_VERSION"

echo ""
echo "========================================"
echo "             更新完成"
echo "========================================"
echo ""
echo "[✓] 模块：$FINAL_ID"
echo "[✓] 版本：$FINAL_VERSION"
echo "[✓] 版本号：$FINAL_VERSIONCODE"
echo ""
echo "[✓] 模块安装成功"
echo "[→] 请返回 WebUI 重启 SukiSU"
echo ""

exit 0