#!/system/bin/sh

# ============================================================
# 主模块授权初始化
# ============================================================

MODDIR="${0%/*}"

LICENSE="$MODDIR/.license"


# ============================================================
# 验证已有授权
# ============================================================

if [ -s "$LICENSE" ]; then

    TOKEN="$(cat "$LICENSE" 2>/dev/null)"

    LENGTH="$(
        printf '%s' "$TOKEN" |
        wc -c 2>/dev/null
    )"


    if [ "$LENGTH" -eq 64 ]; then

        if ! printf '%s' "$TOKEN" |
            grep -q '[^0-9a-fA-F]'; then

            chmod 0600 "$LICENSE" 2>/dev/null

            exit 0

        fi

    fi


    # 已存在但无效
    rm -f "$LICENSE"

fi


# ============================================================
# 生成随机授权 Token
# ============================================================

TOKEN=""


if [ -r /dev/urandom ]; then

    TOKEN="$(
        od -An -N32 -tx1 /dev/urandom 2>/dev/null |
        tr -d ' \n'
    )"

fi


# ============================================================
# 随机源不可用
# ============================================================

if [ -z "$TOKEN" ]; then
    exit 1
fi


# ============================================================
# Token 长度检查
# ============================================================

LENGTH="$(
    printf '%s' "$TOKEN" |
    wc -c 2>/dev/null
)"


if [ "$LENGTH" -ne 64 ]; then
    exit 1
fi


# ============================================================
# Hex 检查
# ============================================================

if printf '%s' "$TOKEN" |
    grep -q '[^0-9a-fA-F]'; then

    exit 1

fi


# ============================================================
# 安全写入
# ============================================================

umask 077

TEMP_LICENSE="$LICENSE.tmp.$$"


if ! printf '%s\n' "$TOKEN" > "$TEMP_LICENSE"; then

    rm -f "$TEMP_LICENSE"

    exit 1

fi


chmod 0600 "$TEMP_LICENSE" 2>/dev/null


if ! mv -f "$TEMP_LICENSE" "$LICENSE"; then

    rm -f "$TEMP_LICENSE"

    exit 1

fi


exit 0
