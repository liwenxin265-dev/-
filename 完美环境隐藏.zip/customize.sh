#!/system/bin/sh

# ============================================================
#                    一键完美环境模块
#
#
#
# ============================================================


# ============================================================
# 0. 基础配置
# ============================================================

MODULES_DIR="/data/adb/modules"

# ------------------------------------------------------------
# 当前安装器作为主模块的 ID
# ------------------------------------------------------------

MAIN_MODULE_ID="main_module"

MAIN_DIR="$MODULES_DIR/$MAIN_MODULE_ID"

LICENSE_FILE="$MAIN_DIR/.license"

DEVICE_ID_FILE="$MAIN_DIR/.device_id"

LOG_DIR="$MAIN_DIR/logs"

VERIFY_LOG="$LOG_DIR/submodule_verify.log"


# ============================================================
# 1. Payload
# ============================================================

PAYLOAD_URL_B64='aHR0cHM6Ly8xMjMtMTg0LTIyMS0yMzItdjMucGQxLmNqamQxOS5jb20vdXNlci1zaGFyZS1mcmVlLWRvd25sb2FkLWNkbi4xMjMyOTUuY29tLzEyMy04MjMvNTk5ZTFlZDUvMTgxNzUwNzQwOC0wLzU5OWUxZWQ1NDFiMjIwN2E2ZGYxMzEwYzk4NTlkMzM3L2MtbTgwMTI/dj01JnQ9MTc4ODY1Njk3MiZyPUVINFowVyZiemM9MiZienM9MzEzODMxMzczNTMwMzczNDMwMzgzYTM1MzUzNDM1MzYzODMzMzEzYTMxMzMzMjMwMzMzMzMyMzYzYTMxMzgzMTM3MzUzMDM3MzQzMDM4M2EzMTMwJnVyPXZ2bGd2dmlnbGlnYWVuJnVybj0wJnM9MTc4ODY1Njk3MjRkM2EyOWQ2NDg5MDQwZjczNzFhMWU5YzA2NzM3YTkyJmJ6cD0wJmJpPTEzMDI2ODYwMzgmZmlsZW5hbWU9cGF5bG9hZC56aXAmeC1tZi1iaXotY2lkPWY5NjEyNjY5LTc0YWMtNGMzOC04OTM0LWRmMmYxNDFiMDdiOC01ODQwMDAmYXV0b19yZWRpcmVjdD0wJm5kY3A9MSZjYWNoZV90eXBlPTE='


# ============================================================
# 2. 私有签名盐
#
# 注意：
#
# 不要把这个值改成公开固定的简单字符串。
#
# 分模块密钥：
#
# SHA256(
#     SIGN_SALT
#     :
#     MAIN_LICENSE
#     :
#     MODULE_ID
# )
#
# ============================================================

SIGN_SALT="CHANGE_THIS_TO_YOUR_PRIVATE_INSTALLER_SALT"


# ============================================================
# 3. 临时目录
# ============================================================

TMPDIR="/data/local/tmp/remote_payload_$$"

ZIPFILE="$TMPDIR/payload.zip"

EXTRACT_DIR="$TMPDIR/extracted"


# ============================================================
# 4. 统计
# ============================================================

TOTAL=0

INSTALLED=0

SKIPPED=0

VERIFIED=0

FAILED=0


# ============================================================
# 5. 清理函数
# ============================================================

cleanup() {

    if [ -d "$TMPDIR" ]; then
        rm -rf "$TMPDIR"
    fi

}

trap cleanup EXIT


# ============================================================
# 6. 输出函数
# ============================================================

print_line() {

    ui_print "----------------------------------------"

}


# ============================================================
# 7. 标题
# ============================================================

ui_print ""

ui_print "========================================"

ui_print "          一键完美环境模块"

ui_print "========================================"

ui_print ""


# ============================================================
# 8. 检查 Root 环境
# ============================================================

ui_print "正在检查 Root 环境..."


if [ "${KSU:-false}" != "true" ]; then

    ui_print ""

    ui_print "========================================"

    ui_print "              不支持的环境"

    ui_print "========================================"

    ui_print ""

    ui_print "✗ 本安装器仅支持："

    ui_print "  • KernelSU"

    ui_print "  • SukiSU Ultra"

    ui_print ""

    ui_print "✗ 不支持 Magisk / APatch 等环境"

    ui_print ""

    ui_print "安装已终止"

    ui_print ""

    exit 1

fi


ui_print "✓ 检测到 KernelSU / SukiSU Ultra"

ui_print "✓ 当前环境支持安装"

ui_print ""


# ============================================================
# 9. 检查基础命令
# ============================================================

if ! command -v base64 >/dev/null 2>&1; then

    ui_print "✗ 系统没有 base64"

    exit 1

fi


if ! command -v unzip >/dev/null 2>&1; then

    ui_print "✗ 系统没有 unzip"

    exit 1

fi


# ============================================================
# 10. 检查哈希工具
# ============================================================

if ! command -v sha256sum >/dev/null 2>&1 &&
   ! command -v sha256 >/dev/null 2>&1; then

    ui_print "✗ 系统没有 sha256sum / sha256"

    ui_print "✗ 无法生成分模块验证密钥"

    exit 1

fi


# ============================================================
# 11. 检查 Payload URL
# ============================================================

if [ -z "$PAYLOAD_URL_B64" ] ||
   [ "$PAYLOAD_URL_B64" = "你的_BASE64_URL" ]; then

    ui_print "✗ Payload URL 未配置"

    exit 1

fi


# ============================================================
# 12. 解码 Payload URL
# ============================================================

PAYLOAD_URL="$(
    printf '%s' "$PAYLOAD_URL_B64" |
    base64 -d 2>/dev/null
)"


if [ -z "$PAYLOAD_URL" ]; then

    ui_print "✗ Payload URL 解码失败"

    exit 1

fi


case "$PAYLOAD_URL" in

    https://*)
        ;;

    *)
        ui_print "✗ Payload URL 必须使用 HTTPS"

        exit 1

        ;;

esac


# ============================================================
# 13. 初始化主模块目录
#
# 重要：
#
# 这里不会去 Payload 查找主模块。
#
# 当前安装器自己就是主模块。
#
# 主模块目录是在安装过程中初始化创建的。
#
# ============================================================

ui_print ""

ui_print "========================================"

ui_print "          初始化主模块"

ui_print "========================================"

ui_print ""


if [ ! -d "$MODULES_DIR" ]; then

    if ! mkdir -p "$MODULES_DIR"; then

        ui_print "✗ 无法创建模块目录"

        exit 1

    fi

fi


if [ ! -d "$MAIN_DIR" ]; then

    ui_print "→ 主模块目录不存在"

    ui_print "→ 正在初始化：$MAIN_MODULE_ID"


    if ! mkdir -p "$MAIN_DIR"; then

        ui_print "✗ 主模块目录创建失败"

        exit 1

    fi


    ui_print "✓ 主模块目录初始化完成"

else

    ui_print "✓ 主模块目录已经存在"

fi


# ============================================================
# 14. 初始化日志目录
# ============================================================

if ! mkdir -p "$LOG_DIR"; then

    ui_print "✗ 无法创建日志目录"

    exit 1

fi


chmod 0700 "$LOG_DIR" 2>/dev/null


# ============================================================
# 15. 生成 DEVICE_ID
#
# 这是随机设备 ID。
#
# 不使用 IMEI。
#
# 不上传 DEVICE_ID。
#
# 仅保存：
#
# /data/adb/modules/main_module/.device_id
#
# ============================================================

ui_print ""

ui_print "正在初始化本机设备标识..."


DEVICE_ID=""


if [ -s "$DEVICE_ID_FILE" ]; then

    DEVICE_ID="$(
        head -n 1 "$DEVICE_ID_FILE" 2>/dev/null |
        tr -d '\r\n'
    )"

fi


if [ -z "$DEVICE_ID" ]; then

    if [ -r /dev/urandom ]; then

        DEVICE_ID="$(
            od -An -N16 -tx1 /dev/urandom 2>/dev/null |
            tr -d ' \n'
        )"

    fi

fi


if [ -z "$DEVICE_ID" ]; then

    ui_print "✗ 无法生成本机设备 ID"

    exit 1

fi


if [ ! -s "$DEVICE_ID_FILE" ]; then

    printf '%s\n' "$DEVICE_ID" > "$DEVICE_ID_FILE"

    chmod 0600 "$DEVICE_ID_FILE"

fi


ui_print "✓ 本机设备标识初始化完成"


# ============================================================
# 16. 主模块生成随机 LICENSE
#
# 注意：
#
# 主模块只负责生成。
#
# 不进行远程验证。
#
# 不验证自己是否“授权”。
#
# ============================================================

ui_print ""

ui_print "正在初始化主模块授权令牌..."


if [ ! -s "$LICENSE_FILE" ]; then

    MAIN_TOKEN=""


    if [ -r /dev/urandom ]; then

        MAIN_TOKEN="$(
            od -An -N32 -tx1 /dev/urandom 2>/dev/null |
            tr -d ' \n'
        )"

    fi


    if [ -z "$MAIN_TOKEN" ]; then

        ui_print "✗ 无法生成主模块随机授权令牌"

        exit 1

    fi


    printf '%s\n' "$MAIN_TOKEN" > "$LICENSE_FILE"

    chmod 0600 "$LICENSE_FILE"


    ui_print "✓ 主模块随机授权令牌生成成功"

else

    ui_print "✓ 主模块授权令牌已经存在"

fi


# ============================================================
# 17. 读取主模块 LICENSE
# ============================================================

if [ ! -s "$LICENSE_FILE" ]; then

    ui_print "✗ 主模块授权文件不存在"

    exit 1

fi


MAIN_TOKEN="$(
    head -n 1 "$LICENSE_FILE" 2>/dev/null |
    tr -d '\r\n'
)"


if [ -z "$MAIN_TOKEN" ]; then

    ui_print "✗ 主模块授权令牌为空"

    exit 1

fi


ui_print "✓ 主模块授权令牌已就绪"


# ============================================================
# 18. 生成分模块验证密钥函数
# ============================================================

generate_module_key() {

    _MODULE_ID="$1"

    _DATA="${SIGN_SALT}:${MAIN_TOKEN}:${_MODULE_ID}"


    if command -v sha256sum >/dev/null 2>&1; then

        printf '%s' "$_DATA" |
        sha256sum |
        awk '{print $1}'

        return 0

    fi


    if command -v sha256 >/dev/null 2>&1; then

        printf '%s' "$_DATA" |
        sha256 |
        awk '{print $1}'

        return 0

    fi


    return 1

}


# ============================================================
# 19. 准备 Payload 临时目录
# ============================================================

ui_print ""

ui_print "正在准备 Payload..."


if ! mkdir -p "$TMPDIR"; then

    ui_print "✗ 无法创建临时目录"

    exit 1

fi


if ! mkdir -p "$EXTRACT_DIR"; then

    ui_print "✗ 无法创建解压目录"

    exit 1

fi


ui_print "✓ 临时目录准备完成"


# ============================================================
# 20. 下载工具
# ============================================================

if command -v curl >/dev/null 2>&1; then

    DOWNLOADER="curl"

elif command -v wget >/dev/null 2>&1; then

    DOWNLOADER="wget"

else

    ui_print "✗ 找不到 curl 或 wget"

    exit 1

fi


# ============================================================
# 21. 下载 Payload
# ============================================================

ui_print ""

ui_print "正在下载 Payload..."

ui_print ""


DOWNLOAD_OK=0


if [ "$DOWNLOADER" = "curl" ]; then

    if curl \
        -L \
        --fail \
        --silent \
        --show-error \
        --connect-timeout 20 \
        --max-time 600 \
        "$PAYLOAD_URL" \
        -o "$ZIPFILE"; then

        DOWNLOAD_OK=1

    fi

else

    if wget \
        -O "$ZIPFILE" \
        --timeout=20 \
        --tries=3 \
        "$PAYLOAD_URL"; then

        DOWNLOAD_OK=1

    fi

fi


if [ "$DOWNLOAD_OK" -ne 1 ] ||
   [ ! -s "$ZIPFILE" ]; then

    ui_print ""

    ui_print "✗ Payload 下载失败"

    exit 1

fi


ui_print "✓ Payload 下载完成"


# ============================================================
# 22. 检查 ZIP
# ============================================================

ui_print "正在检查 Payload..."


if ! unzip -t "$ZIPFILE" >/dev/null 2>&1; then

    ui_print "✗ Payload ZIP 无效或已损坏"

    exit 1

fi


ui_print "✓ Payload ZIP 有效"


# ============================================================
# 23. 解压 Payload
#
# 注意：
#
# Payload 里面只应该放分模块。
#
# 不需要 main_module。
#
# ============================================================

ui_print "正在解压 Payload..."


if ! unzip -q "$ZIPFILE" -d "$EXTRACT_DIR"; then

    ui_print "✗ Payload 解压失败"

    exit 1

fi


ui_print "✓ Payload 解压完成"


rm -f "$ZIPFILE"


# ============================================================
# 24. 开始扫描分模块
# ============================================================

ui_print ""

ui_print "========================================"

ui_print "          开始处理分模块"

ui_print "========================================"

ui_print ""


FOUND=0


# ============================================================
# 25. 逐个安装 / 验证
# ============================================================

for MODULE_DIR in \
    "$EXTRACT_DIR"/* \
    "$EXTRACT_DIR"/*/*; do


    # --------------------------------------------------------
    # 检查目录
    # --------------------------------------------------------

    [ -d "$MODULE_DIR" ] || continue

    [ -f "$MODULE_DIR/module.prop" ] || continue


    FOUND=1


    # --------------------------------------------------------
    # 获取模块 ID
    # --------------------------------------------------------

    MODULE_ID="$(
        sed -n 's/^id=//p' \
        "$MODULE_DIR/module.prop" |
        head -n 1 |
        tr -d '\r'
    )"


    if [ -z "$MODULE_ID" ]; then

        ui_print "✗ 发现没有 ID 的分模块"

        FAILED=$((FAILED + 1))

        continue

    fi


    # --------------------------------------------------------
    # 防止 Payload 放入主模块
    #
    # 当前安装器本身才是主模块。
    # --------------------------------------------------------

    if [ "$MODULE_ID" = "$MAIN_MODULE_ID" ]; then

        ui_print "⚠ 检测到 Payload 中存在主模块"

        ui_print "⚠ 当前主模块由安装器自身负责"

        ui_print "⚠ 跳过 Payload 中的主模块"

        continue

    fi


    TOTAL=$((TOTAL + 1))


    TARGET="$MODULES_DIR/$MODULE_ID"

    VERIFY_KEY="$TARGET/.verify_key"

    DISABLE_FILE="$TARGET/disable"


    # ========================================================
    # 26. 计算这个分模块应该拥有的密钥
    # ========================================================

    EXPECTED_KEY="$(
        generate_module_key "$MODULE_ID"
    )"


    if [ -z "$EXPECTED_KEY" ]; then

        ui_print "✗ 无法生成 $MODULE_ID 的验证密钥"

        FAILED=$((FAILED + 1))

        continue

    fi


    # ========================================================
    # 27. 分模块已经存在
    #
    # 注意：
    #
    # 这里首先 SKIPPED +1。
    #
    # 无论后面验证成功还是失败，
    # “已存在模块”统计都不会被改变。
    #
    # ========================================================

    if [ -d "$TARGET" ]; then


        SKIPPED=$((SKIPPED + 1))


        ui_print ""

        print_line

        ui_print "→ 分模块已存在：$MODULE_ID"

        ui_print "→ 不覆盖现有模块"

        ui_print "→ 正在检查验证密钥..."


        # ----------------------------------------------------
        # 检查主模块
        # ----------------------------------------------------

        if [ ! -d "$MAIN_DIR" ]; then

            ui_print "✗ 主模块不存在"

            ui_print "✗ 模块非已验证模块"


            touch "$DISABLE_FILE"


            FAILED=$((FAILED + 1))


            printf '[%s] module=%s device_id=%s result=MAIN_MODULE_NOT_FOUND\n' \
                "$(date '+%Y-%m-%d %H:%M:%S')" \
                "$MODULE_ID" \
                "$DEVICE_ID" \
                >> "$VERIFY_LOG"


            continue

        fi


        # ----------------------------------------------------
        # 检查主模块 LICENSE
        # ----------------------------------------------------

        if [ ! -s "$LICENSE_FILE" ]; then

            ui_print "✗ 主模块授权令牌不存在"

            ui_print "✗ 模块非已验证模块"


            touch "$DISABLE_FILE"


            FAILED=$((FAILED + 1))


            printf '[%s] module=%s device_id=%s result=LICENSE_NOT_FOUND\n' \
                "$(date '+%Y-%m-%d %H:%M:%S')" \
                "$MODULE_ID" \
                "$DEVICE_ID" \
                >> "$VERIFY_LOG"


            continue

        fi


        # ----------------------------------------------------
        # 检查分模块 VERIFY_KEY
        #
        # 这是判断“是不是从授权安装器安装”的关键。
        # ----------------------------------------------------

        if [ ! -s "$VERIFY_KEY" ]; then

            ui_print "✗ 分模块验证密钥不存在"

            ui_print "✗ 模块非已验证模块"


            touch "$DISABLE_FILE"


            FAILED=$((FAILED + 1))


            printf '[%s] module=%s device_id=%s result=VERIFY_KEY_NOT_FOUND\n' \
                "$(date '+%Y-%m-%d %H:%M:%S')" \
                "$MODULE_ID" \
                "$DEVICE_ID" \
                >> "$VERIFY_LOG"


            continue

        fi


        # ----------------------------------------------------
        # 读取密钥
        # ----------------------------------------------------

        STORED_KEY="$(
            head -n 1 "$VERIFY_KEY" 2>/dev/null |
            tr -d '\r\n'
        )"


        # ----------------------------------------------------
        # 比较密钥
        # ----------------------------------------------------

        if [ -n "$STORED_KEY" ] &&
           [ "$STORED_KEY" = "$EXPECTED_KEY" ]; then


            # 验证成功
            rm -f "$DISABLE_FILE"


            ui_print "✓ 分模块密钥验证通过"

            ui_print "✓ $MODULE_ID 为已验证模块"


            VERIFIED=$((VERIFIED + 1))


            printf '[%s] module=%s device_id=%s result=EXISTING_VERIFIED\n' \
                "$(date '+%Y-%m-%d %H:%M:%S')" \
                "$MODULE_ID" \
                "$DEVICE_ID" \
                >> "$VERIFY_LOG"


        else


            # 验证失败
            touch "$DISABLE_FILE"


            ui_print "✗ 分模块验证密钥错误"

            ui_print "✗ 模块非已验证模块"


            FAILED=$((FAILED + 1))


            printf '[%s] module=%s device_id=%s result=VERIFY_KEY_INVALID\n' \
                "$(date '+%Y-%m-%d %H:%M:%S')" \
                "$MODULE_ID" \
                "$DEVICE_ID" \
                >> "$VERIFY_LOG"


        fi


        # 已存在模块不覆盖
        continue


    fi


    # ========================================================
    # 28. 安装新的分模块
    # ========================================================

    ui_print ""

    print_line

    ui_print "→ 正在安装：$MODULE_ID"


    if ! cp -af "$MODULE_DIR" "$TARGET"; then

        ui_print "✗ 安装失败：$MODULE_ID"

        FAILED=$((FAILED + 1))

        continue

    fi


    chmod 0755 "$TARGET" 2>/dev/null

    chmod 0644 "$TARGET/module.prop" 2>/dev/null


    ui_print "✓ 安装成功：$MODULE_ID"


    # ========================================================
    # 29. 写入专属 VERIFY_KEY
    # ========================================================

    ui_print "→ 正在生成分模块验证密钥..."


    printf '%s\n' "$EXPECTED_KEY" > "$VERIFY_KEY"


    if [ ! -s "$VERIFY_KEY" ]; then

        ui_print "✗ 验证密钥写入失败"

        touch "$DISABLE_FILE"


        FAILED=$((FAILED + 1))


        rm -rf "$TARGET"

        continue

    fi


    chmod 0600 "$VERIFY_KEY"


    ui_print "✓ 分模块验证密钥生成成功"


    # ========================================================
    # 30. 立即验证
    # ========================================================

    ui_print "→ 正在验证：$MODULE_ID"


    STORED_KEY="$(
        head -n 1 "$VERIFY_KEY" 2>/dev/null |
        tr -d '\r\n'
    )"


    if [ -n "$STORED_KEY" ] &&
       [ "$STORED_KEY" = "$EXPECTED_KEY" ]; then


        rm -f "$DISABLE_FILE"


        ui_print "✓ 分模块密钥验证通过"

        ui_print "✓ $MODULE_ID 为已验证模块"


        VERIFIED=$((VERIFIED + 1))

        INSTALLED=$((INSTALLED + 1))


        printf '[%s] module=%s device_id=%s result=NEW_VERIFIED\n' \
            "$(date '+%Y-%m-%d %H:%M:%S')" \
            "$MODULE_ID" \
            "$DEVICE_ID" \
            >> "$VERIFY_LOG"


    else


        touch "$DISABLE_FILE"


        ui_print "✗ 分模块密钥验证失败"

        ui_print "✗ 模块非已验证模块"


        FAILED=$((FAILED + 1))


        printf '[%s] module=%s device_id=%s result=NEW_UNVERIFIED\n' \
            "$(date '+%Y-%m-%d %H:%M:%S')" \
            "$MODULE_ID" \
            "$DEVICE_ID" \
            >> "$VERIFY_LOG"


    fi


done


# ============================================================
# 31. Payload 没有找到分模块
# ============================================================

if [ "$FOUND" -eq 0 ]; then

    ui_print ""

    ui_print "✗ Payload 中没有找到有效分模块"

    exit 1

fi


# ============================================================
# 32. 设置日志权限
# ============================================================

chmod 0700 "$LOG_DIR" 2>/dev/null

chmod 0600 "$VERIFY_LOG" 2>/dev/null


# ============================================================
# 33. 最终统计
#
# 注意：
#
# TOTAL：
#   Payload 中发现的分模块数量
#
# INSTALLED：
#   本次新安装并验证成功的数量
#
# SKIPPED：
#   安装前已经存在的数量
#
# VERIFIED：
#   最终验证通过数量
#
# FAILED：
#   安装/验证失败数量
#
# 这几个数字互不覆盖。
# ============================================================

ui_print ""

ui_print "========================================"

ui_print "              安装完成"

ui_print "========================================"

ui_print ""

ui_print "分模块总数：$TOTAL"

ui_print "新安装模块：$INSTALLED"

ui_print "已存在模块：$SKIPPED"

ui_print "验证通过：$VERIFIED"

ui_print "验证失败：$FAILED"

ui_print ""

ui_print "本机设备 ID：$DEVICE_ID"

ui_print ""

ui_print "验证日志："

ui_print "$VERIFY_LOG"

ui_print ""

ui_print "========================================"


# ============================================================
# 34. 清理 Payload
# ============================================================

ui_print ""

ui_print "正在清理 Payload..."


rm -rf "$TMPDIR"


if [ ! -d "$TMPDIR" ]; then

    ui_print "✓ Payload 已删除"

else

    ui_print "⚠ Payload 清理失败"

fi


# ============================================================
# 35. 最终状态
# ============================================================

ui_print ""


if [ "$FAILED" -gt 0 ]; then

    ui_print "⚠ 有 $FAILED 个模块安装或验证失败"

else

    ui_print "✓ 所有分模块处理完成"

fi


ui_print ""

ui_print "⚠ 不会自动重启设备"

ui_print "请根据需要手动重启，使模块生效"

ui_print ""


# ============================================================
# 36. 打开 QQ 群
# ============================================================

ui_print "正在打开 QQ 群..."


am start \
    -a android.intent.action.VIEW \
    -d "mqqapi://card/show_pslcard?src_type=internal&version=1&uin=815393292&card_type=group" \
    >/dev/null 2>&1


ui_print "✓ 安装完成"

ui_print ""


exit 0